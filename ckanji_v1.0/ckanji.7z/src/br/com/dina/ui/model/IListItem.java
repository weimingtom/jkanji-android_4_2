package br.com.dina.ui.model;

public interface IListItem {

	public boolean isClickable();
	
	public void setClickable(boolean clickable);
	
}

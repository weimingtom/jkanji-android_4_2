package com.iteye.weimingtom.ckanji;

import java.util.ArrayList;

import br.com.dina.ui.model.BasicItem;
import br.com.dina.ui.widget.UITableView;
import br.com.dina.ui.widget.UITableView.ClickListener;
import android.app.Activity;
import android.app.AlertDialog;
import android.app.Dialog;
import android.content.ActivityNotFoundException;
import android.content.Context;
import android.content.DialogInterface;
import android.content.DialogInterface.OnCancelListener;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.SharedPreferences.Editor;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.net.Uri;
import android.os.AsyncTask;
import android.os.Bundle;
import android.text.ClipboardManager;
import android.text.format.Time;
import android.util.Log;
import android.view.Menu;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.inputmethod.InputMethodManager;
import android.widget.Button;
import android.widget.CompoundButton;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.LinearLayout;
import android.widget.Toast;
import android.widget.ViewFlipper;
import android.widget.CompoundButton.OnCheckedChangeListener;
import android.widget.RadioButton;

/**
 * CuteKanji
 * @author weimingtom
 * @see https://github.com/ling0322/danci
 * @see http://blog.csdn.net/billpig/article/details/6634481
 * @see http://vndb.org/v1657
 * @see http://stackoverflow.com/questions/6100034/setting-image-source-for-togglebutton
 * @see http://developer.android.com/guide/topics/resources/drawable-resource.html#LayerList
 * 
 */

//android.R.anim.fade_in;
//android.R.anim.fade_out;
//android.R.anim.slide_in_left;
//android.R.anim.slide_out_right;
public class CKanjiActivity extends Activity {
	private final static boolean D = false;
	private final static String TAG = "CKanjiActivity";
	
	private static final String SHARE_PREF_NAME = "pref";
	private static final String SHARE_PREF_SEARCH_TYPE = "searchType";
	
	private final static int SEARCH_TYPE_PREFIX = 0;
	private final static int SEARCH_TYPE_SUFFIX = 1;
	private final static int SEARCH_TYPE_INFIX = 2;
	private final static int SEARCH_TYPE_FULLTEXT = 3;
	private final static String[] SEARCH_TYPE_ITEMS = new String[] {
		"前缀",
		"后缀",
		"包含",
		"全文",
	};
	private final static int DIALOG_LIST = 1;

	private EditText editTextInput;
	private ImageButton imageButtonInputClear;
	private Button buttonSearch;
	private Button buttonTitleBack, buttonTitleSetting;
	private UITableView tableViewSearchStatus, tableViewSearch, tableViewDetail, tableViewHistory, tableViewSettings, tableViewAbout;
	private RadioButton radioButtonSearch, radioButtonDetail, radioButtonHistory, radioButtonSettings;
	private ViewFlipper mFlipper;
	private LinearLayout linearLayoutInput;
	private Button buttonClear;
	
	private String dataBaseFileName;
	private SearchTask searchTask;
	private ArrayList<WordItem> wordItems;
	private int currentWordItem = -1;
	
	private CKanjiHistoryDataSource dataSrc;
	private ArrayList<CKanjiHistoryItem> historyItems;
	
	
    /** Called when the activity is first created. */
    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.main);
        
        editTextInput = (EditText) findViewById(R.id.editTextInput);
        imageButtonInputClear = (ImageButton) findViewById(R.id.imageButtonInputClear);
        buttonSearch = (Button) findViewById(R.id.buttonSearch);
        buttonTitleBack = (Button) findViewById(R.id.buttonTitleBack);
        buttonTitleSetting = (Button) findViewById(R.id.buttonTitleSetting);
        radioButtonSearch = (RadioButton) findViewById(R.id.radioButtonSearch);
        radioButtonDetail = (RadioButton) findViewById(R.id.radioButtonDetail);
        radioButtonHistory = (RadioButton) findViewById(R.id.radioButtonHistory);
        radioButtonSettings = (RadioButton) findViewById(R.id.radioButtonSettings);
        mFlipper = (ViewFlipper) this.findViewById(R.id.flipper);
        tableViewSearchStatus = (UITableView) findViewById(R.id.tableViewSearchStatus);
        tableViewSearch = (UITableView) findViewById(R.id.tableViewSearch);   
        tableViewDetail = (UITableView) findViewById(R.id.tableViewDetail);
        tableViewHistory = (UITableView) findViewById(R.id.tableViewHistory);   
        tableViewSettings = (UITableView) findViewById(R.id.tableViewSettings);   
        tableViewAbout = (UITableView) findViewById(R.id.tableViewAbout);
        linearLayoutInput = (LinearLayout) findViewById(R.id.linearLayoutInput);
        buttonClear = (Button) findViewById(R.id.buttonClear);
        
        wordItems = new ArrayList<WordItem>();
        
        buttonTitleSetting.setText(getCurrentSearchType());
        
        imageButtonInputClear.setOnClickListener(new OnClickListener() {
			@Override
			public void onClick(View v) {
				editTextInput.setText("");
				editTextInput.requestFocus();
				InputMethodManager imm = (InputMethodManager)
						getSystemService(Context.INPUT_METHOD_SERVICE);
				imm.showSoftInput(editTextInput, 0);
			}
        });
        buttonSearch.setOnClickListener(new OnClickListener() {
			@Override
			public void onClick(View v) {
				startSearch(true);
			}
        });
        buttonTitleBack.setOnClickListener(new OnClickListener() {
			@Override
			public void onClick(View v) {
				backScreen();
			}
        });
        buttonTitleSetting.setOnClickListener(new OnClickListener() {
			@Override
			public void onClick(View v) {
				if (radioButtonSettings.isChecked()) {
					//radioButtonSearch.setChecked(true);
				} else if (radioButtonHistory.isChecked()) {
		        	tableViewHistory.clear();
		            tableViewHistory.commit();
		            historyItems = null;
		        	dataSrc = new CKanjiHistoryDataSource(CKanjiActivity.this);
		        	dataSrc.open();
		        	dataSrc.deleteAllItem();
		    		dataSrc.close();
				} else {
					//radioButtonSettings.setChecked(true);
					showDialog(DIALOG_LIST);
				}
			}
        });
        radioButtonSearch.setOnCheckedChangeListener(new OnCheckedChangeListener() {
			@Override
			public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
				if (isChecked) {
					buttonTitleBack.setVisibility(RadioButton.VISIBLE);
					buttonTitleBack.setText("退出");
					buttonTitleSetting.setVisibility(RadioButton.VISIBLE);
			    	buttonTitleSetting.setText(getCurrentSearchType());
			    	mFlipper.setDisplayedChild(0);
				}
			}
        });
        radioButtonDetail.setOnCheckedChangeListener(new OnCheckedChangeListener() {
			@Override
			public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
				if (isChecked) {
					buttonTitleBack.setVisibility(RadioButton.GONE);
					buttonTitleSetting.setVisibility(RadioButton.GONE);
					mFlipper.setDisplayedChild(1);
					InputMethodManager inputMethodManager = (InputMethodManager) getSystemService(Context.INPUT_METHOD_SERVICE);
					inputMethodManager.hideSoftInputFromWindow(editTextInput.getWindowToken(), 0);
				}
			}
        });
        radioButtonHistory.setOnCheckedChangeListener(new OnCheckedChangeListener() {
			@Override
			public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
				if (isChecked) {
					buttonTitleBack.setVisibility(RadioButton.GONE);
					buttonTitleSetting.setVisibility(RadioButton.VISIBLE);
					buttonTitleSetting.setText("清空");
					mFlipper.setDisplayedChild(2);
					InputMethodManager inputMethodManager = (InputMethodManager) getSystemService(Context.INPUT_METHOD_SERVICE);
					inputMethodManager.hideSoftInputFromWindow(editTextInput.getWindowToken(), 0);
				}
			}
        });
        radioButtonSettings.setOnCheckedChangeListener(new OnCheckedChangeListener() {
			@Override
			public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
				if (isChecked) {
					buttonTitleBack.setVisibility(RadioButton.GONE);
					buttonTitleSetting.setVisibility(RadioButton.GONE);
					mFlipper.setDisplayedChild(3);
					InputMethodManager inputMethodManager = (InputMethodManager) getSystemService(Context.INPUT_METHOD_SERVICE);
					inputMethodManager.hideSoftInputFromWindow(editTextInput.getWindowToken(), 0);
				}
			}
        });
        buttonClear.setOnClickListener(new OnClickListener() {
			@Override
			public void onClick(View v) {
				if (searchTask == null) {
					editTextInput.setText("");
					editTextInput.requestFocus();
					InputMethodManager imm = (InputMethodManager)
							getSystemService(Context.INPUT_METHOD_SERVICE);
					imm.showSoftInput(editTextInput, 0);
					tableViewSearch.clear();
					tableViewSearch.commit();
					radioButtonSearch.setChecked(true);
				}
			}
        });
        
        showSearchLoadingStart();
        tableViewSearchStatus.setClickListener(new ClickListener() {
    		@Override
    		public void onClick(int index) {
    			if (!buttonSearch.isEnabled()) {
    				//重试
    				new LoadDataTask().execute();
    			} else {
    				
    			}
    		}
        });
        tableViewSearch.setClickListener(new ClickListener() {
    		@Override
    		public void onClick(int index) {
    			//shareTable(index);
    			updateDetail(index);
    		}
        });
        buttonSearch.postDelayed(new Runnable() {
			@Override
			public void run() {
				new LoadDataTask().execute();
			}
        }, 500);
        
        tableViewHistory.setClickListener(new ClickListener() {
    		@Override
    		public void onClick(int index) {
    			if (historyItems != null && index >= 0 && index < historyItems.size()) {
    				CKanjiHistoryItem item = historyItems.get(historyItems.size() - 1 - index);
    				String desc = item.getPlainDesc();
    				editTextInput.setText(desc);
    				radioButtonSearch.setChecked(true);
    				startSearch(false);
    			}
    		}
        });
        updateHistory();

    	updateSettings();
    	tableViewSettings.setClickListener(new ClickListener() {
    		@Override
    		public void onClick(int index) {
    			switch (index) {
    			case 1:
    				//setLastSearchType(nextSearchType());
    				showDialog(DIALOG_LIST);
    				break;
    				
    			case 2:
    				new LoadDataTask().execute();
    				break;
    			}
    			updateSettings();
    		}
        });
    	
    	updateAbout();
    	tableViewAbout.setClickListener(new ClickListener() {
    		@Override
    		public void onClick(int index) {
    			switch (index) {
    			case 5:
    				openBlog();
    				break;
    			
    			case 6:
    				sendEmail();
    				break;
    			}
    		}
        });
    	
    	tableViewDetail.setClickListener(new ClickListener() {
    		@Override
    		public void onClick(int index) {
    			shareWord(index);
    		}
        });
    }

    private void startSearch(boolean isRecorded) {
		String keyword = editTextInput.getText().toString();
		if (searchTask == null && keyword != null && keyword.length() > 0) {
	    	if (isRecorded) {
	        	tableViewHistory.clear();
	        	dataSrc = new CKanjiHistoryDataSource(this);
	        	dataSrc.open();
	        	historyItems = dataSrc.getAllItems();
	        	if (historyItems != null) {
	        		for (int i = historyItems.size() - 1; i >= 0; i--) {
	        			CKanjiHistoryItem item = historyItems.get(i);
	        			if (item != null && item.getPlainDesc() != null && item.getPlainDesc().equals(keyword)) {
	        				dataSrc.deleteItem(item);
	        			}
	        		}
	        	}
	        	CKanjiHistoryItem newItem = new CKanjiHistoryItem();
	        	newItem.setId(-1);
	        	newItem.setPlainDesc(keyword);
	        	dataSrc.createItem(newItem);
	        	historyItems = dataSrc.getAllItems();
	        	if (historyItems != null) {
	        		for (int i = historyItems.size() - 1; i >= 0; i--) {
	        			CKanjiHistoryItem item = historyItems.get(i);
	        			String desc = item.getPlainDesc();
	        			Time time = item.getPlainTime();
	        			String timeStr = time.format("%Y-%m-%d %H:%M:%S");
	        	        tableViewHistory.addBasicItem(desc, timeStr);
	        		}
	        	}
	    		dataSrc.close();
	            tableViewHistory.commit();
	    	}
			searchTask = new SearchTask();
			searchTask.execute(keyword, Integer.toString(getLastSearchType()));
		} else {
			showSearchKeywordEmpty();
		}
    }
    
	private void showSearchLoadingStart() {
    	tableViewSearchStatus.clear();
    	tableViewSearchStatus.addBasicItem(new BasicItem("正在复制数据库...", null, false));
    	tableViewSearchStatus.commit();
    }
    
    private void showSearchLoadingSuccess() {
    	if (D) {
    		Log.d(TAG, "showSearchLoadingSuccess");
    	}
    	buttonSearch.setEnabled(true);
    	tableViewSearchStatus.clear();
    	tableViewSearchStatus.addBasicItem(new BasicItem("请输入关键词", null, false));
    	tableViewSearchStatus.commit();
    }
    
    private void showSearchLoadingFailed() {
    	if (D) {
    		Log.d(TAG, "showSearchLoadingFailed");
    	}
    	buttonSearch.setEnabled(false);
    	tableViewSearchStatus.clear();
    	tableViewSearchStatus.addBasicItem(new BasicItem("复制失败，请检查SD卡后重试", null));
    	tableViewSearchStatus.commit();
    }

    private void showSearchStart() {
    	if (D) {
    		Log.d(TAG, "showSearchStart");
    	}
    	buttonSearch.setEnabled(false);
    	tableViewSearchStatus.clear();
    	tableViewSearchStatus.addBasicItem(new BasicItem("搜索中...", null, false));
    	tableViewSearchStatus.commit();
    }

    private void showSearchEnd(String keyword, int count) {
    	if (D) {
    		Log.d(TAG, "showSearchEnd");
    	}
    	tableViewSearchStatus.clear();
    	if (count > 0) {
    		tableViewSearchStatus.addBasicItem(new BasicItem(getSearchTypeString(getLastSearchType()) + ", 关键词：" + keyword + ", 结果：" + count, null, false));
    	} else {
    		tableViewSearchStatus.addBasicItem(new BasicItem(getSearchTypeString(getLastSearchType()) + ", 关键词：" + keyword + ", 搜索结果为空", null, false));
    	}
    	tableViewSearchStatus.commit();
    }
    
    private void showSearchFailed() {
    	if (D) {
    		Log.d(TAG, "showSearchFailed");
    	}
    	buttonSearch.setEnabled(true);
    	tableViewSearchStatus.clear();
    	tableViewSearchStatus.addBasicItem(new BasicItem(getSearchTypeString(getLastSearchType()) + ", 搜索出错，请检查SD卡上是否已经成功了复制数据库文件或退出后再试", null, false));
    	tableViewSearchStatus.commit();
    }

    private void showSearchKeywordEmpty() {
    	if (D) {
    		Log.d(TAG, "showSearchKeywordEmpty");
    	}
    	buttonSearch.setEnabled(true);
    	tableViewSearchStatus.clear();
    	tableViewSearchStatus.addBasicItem(new BasicItem(getSearchTypeString(getLastSearchType()) + ", 关键词为空或未完成", null, false));
    	tableViewSearchStatus.commit();
    }
    
    private void backScreen() {
		if (mFlipper.getDisplayedChild() == 0) {
			finish();
		} else {
			radioButtonSearch.setChecked(true);
		}
    }

    @Override
	public void onBackPressed() {
		if (mFlipper.getDisplayedChild() == 0) {
			super.onBackPressed();
		} else {
			radioButtonSearch.setChecked(true);
		}
	}
    
    @Override
	protected Dialog onCreateDialog(int id) {
    	switch (id) {
        case DIALOG_LIST:
            return new AlertDialog.Builder(this)
                .setTitle("选择匹配方式")
                .setItems(SEARCH_TYPE_ITEMS, new DialogInterface.OnClickListener() {
                    public void onClick(DialogInterface dialog, int which) {
                        setLastSearchType(which);
                        updateSearchType();
                    }
                })
                .setNegativeButton("取消", new DialogInterface.OnClickListener() {
					@Override
					public void onClick(DialogInterface dialog, int which) {
						
					}
                })
                .setOnCancelListener(new OnCancelListener() {
					@Override
					public void onCancel(DialogInterface dialog) {
						
					}
                })
                .create();
    	}
		return super.onCreateDialog(id);
	}
    
    private void updateHistory() {
    	tableViewHistory.clear();
    	dataSrc = new CKanjiHistoryDataSource(this);
    	dataSrc.open();
    	historyItems = dataSrc.getAllItems();
    	if (historyItems != null) {
    		for (int i = historyItems.size() - 1; i >= 0; i--) {
    			CKanjiHistoryItem item = historyItems.get(i);
    			String desc = item.getPlainDesc();
    			Time time = item.getPlainTime();
    			String timeStr = time.format("%Y-%m-%d %H:%M:%S");
    	        tableViewHistory.addBasicItem(desc, timeStr);
    		}
    	}
		dataSrc.close();
        tableViewHistory.commit();
    }
    
	private void updateSettings() {
    	tableViewSettings.clear();
    	tableViewSettings.addBasicItem(new BasicItem("设置", null, false)); // 0
    	tableViewSettings.addBasicItem("匹配类型", getSearchTypeString(getLastSearchType())); // 1
    	tableViewSettings.addBasicItem("复制数据库", "重新复制数据库至SD卡"); // 2
    	tableViewSettings.commit();
    }
    
    private void updateAbout() {
    	tableViewAbout.clear();
    	tableViewAbout.addBasicItem(new BasicItem("关于", null, false)); // 4
    	tableViewAbout.addBasicItem(new BasicItem("应用名称", this.getText(R.string.app_name).toString(), false)); // 1
    	tableViewAbout.addBasicItem(new BasicItem("版本号", this.getString(R.string.app_version_name).toString(), false)); // 2
    	tableViewAbout.addBasicItem(new BasicItem("内部版本号", this.getString(R.string.app_version_code).toString(), false)); // 3
    	tableViewAbout.addBasicItem(new BasicItem("作者", this.getString(R.string.app_author).toString(), false)); // 4
    	tableViewAbout.addBasicItem("我的博客", this.getString(R.string.app_blog).toString()); // 5
    	tableViewAbout.addBasicItem("我的邮箱", this.getString(R.string.app_email).toString()); // 6
    	tableViewAbout.commit();
    }
    
    private void updateSearchType() {
    	if (radioButtonSearch.isChecked()) {
    		buttonTitleSetting.setText(getCurrentSearchType());
    		startSearch(true);
    	}
    	updateSettings();
    }
    
    private void updateDetail(int index) {    	
    	this.currentWordItem = index; 
    	tableViewDetail.clear();
    	if (index >= 0 && index < wordItems.size() && index < wordItems.size()) {
    		WordItem item = wordItems.get(index);
    		if (item != null) {
    			tableViewDetail.addBasicItem(new BasicItem(item.word, null/*"汉字"*/, true));
    			tableViewDetail.addBasicItem(new BasicItem(item.reading, null/*"发音"*/, true));
    			tableViewDetail.addBasicItem(new BasicItem(item.type, null/*"分类"*/, true));
    			tableViewDetail.addBasicItem(new BasicItem(item.meaning, null/*"意思"*/, true));
    			tableViewDetail.addBasicItem(new BasicItem("共享", "共享至其他程序", true));
    		}
    	} else {
			Toast.makeText(this, 
    			"无法获取要共享的字符串", Toast.LENGTH_SHORT)
    			.show();
    	}
    	tableViewDetail.commit();
    	radioButtonDetail.setChecked(true);
    }
    
    private void shareWord(int index) {
    	if (currentWordItem >= 0 && currentWordItem < wordItems.size() && currentWordItem < wordItems.size()) {
    		WordItem item = wordItems.get(currentWordItem);
	    	if (index >= 0 && index <= 3) {
	    		String searchString = "";
	    		switch(index) {
	    		case 0:
	    			searchString = item.word;
	    			break;
	    			
	    		case 1:
	    			searchString = item.reading;
	    			break;
	    			
	    		case 2:
	    			searchString = item.type;
	    			break;
	    			
	    		case 3:
	    			searchString = item.meaning;
	    			break;
	    		}
				ClipboardManager cm = (ClipboardManager) getSystemService(CLIPBOARD_SERVICE);
	            cm.setText(searchString);
	            Toast.makeText(CKanjiActivity.this, "「" + searchString + "」已复制至剪贴板",
	            		Toast.LENGTH_SHORT).show();
	    	} else if (index == 4) {
	    		if (item != null) {	
		    		Intent intent = new Intent();
		    		intent.setAction(Intent.ACTION_SEND);
		    		intent.setType("text/plain");
		            intent.putExtra(Intent.EXTRA_SUBJECT, item.wordStr);
		            intent.putExtra(Intent.EXTRA_TEXT, 
		            	(item.wordStr != null ? 
		            	(item.wordStr + "\n" + item.meanStr) : 
		            	item.meanStr));
		    		try {
		    			startActivity(intent);
		    		} catch (Throwable e) {
		    			e.printStackTrace();
		    			Toast.makeText(this, 
		    				"共享方式出错", Toast.LENGTH_SHORT)
		    				.show();
		    		}
	    		}
	    	}
    	} else {
			Toast.makeText(this, 
				"无法获取要共享的字符串", Toast.LENGTH_SHORT)
				.show();
		}
    }
    
    private String getCurrentSearchType() {
    	int type = getLastSearchType();
    	if (type < 0 || type >= SEARCH_TYPE_ITEMS.length) {
    		return "搜索";
    	} else {
    		return SEARCH_TYPE_ITEMS[type];
    	}
    }
    
    //getLastSearchType()
    private String getSearchTypeString(int type) {
    	switch(type) {
    	case SEARCH_TYPE_PREFIX:
    		return "前缀搜索";
    		
    	case SEARCH_TYPE_INFIX:
    		return "包含搜索";
    		
    	case SEARCH_TYPE_SUFFIX:
    		return "后缀搜索";
    		
    	case SEARCH_TYPE_FULLTEXT:
    		return "全文搜索";
    	}
    	return "";
    }
    
    private int nextSearchType() {
    	switch(getLastSearchType()) {
    	case SEARCH_TYPE_PREFIX:
    		return SEARCH_TYPE_INFIX;
    		
    	case SEARCH_TYPE_INFIX:
    		return SEARCH_TYPE_SUFFIX;
    		
    	case SEARCH_TYPE_SUFFIX:
    		return SEARCH_TYPE_FULLTEXT;
    		
    	case SEARCH_TYPE_FULLTEXT:
    		return SEARCH_TYPE_PREFIX;
    	}
    	return SEARCH_TYPE_PREFIX;
    }
    
    private void openBlog() {
    	Intent intent = new Intent();
    	intent.setAction(Intent.ACTION_VIEW);
    	intent.addCategory(Intent.CATEGORY_DEFAULT);
		intent.addCategory(Intent.CATEGORY_BROWSABLE);
		intent.setDataAndType(Uri.parse(getString(R.string.app_blog)), "*/*");
		try {
			this.startActivity(intent);
		} catch (Throwable e) {
			e.printStackTrace();
			Toast.makeText(this, 
				"找不到可用的应用程序", Toast.LENGTH_SHORT)
				.show();
		}	
    }
    
    private void sendEmail() {
		Intent intent = new Intent();
		intent.setAction(Intent.ACTION_SENDTO);
		intent.setData(Uri.parse("mailto:" + getString(R.string.app_email)));
		intent.putExtra(Intent.EXTRA_SUBJECT, "关于 " + getString(R.string.app_name) + " v" + getString(R.string.app_version_name));
		try {
			startActivity(intent);
		} catch (ActivityNotFoundException e) {
			Toast.makeText(this, "找不到发送邮件的应用程序。", Toast.LENGTH_SHORT).show();
			e.printStackTrace();
		}
    }

    private void setLastSearchType(int type) {
		Editor e = getSharedPreferences(SHARE_PREF_NAME, MODE_PRIVATE).edit();
		e.putInt(SHARE_PREF_SEARCH_TYPE, type);
		e.commit();
    }
    
    private int getLastSearchType() {
		SharedPreferences sp = getSharedPreferences(SHARE_PREF_NAME, MODE_PRIVATE);
		return sp.getInt(SHARE_PREF_SEARCH_TYPE, SEARCH_TYPE_PREFIX);
    }
    
    private final class WordItem {
    	String word;
    	String reading;
    	String type;
    	String meaning;
    	String wordStr, meanStr;
    	
    	public WordItem(String _word, String _meaning, String _reading, String _type, String _wordStr, String _meanStr) {
    		this.word = _word;
    		this.reading = _reading;
    		this.type = _type;
    		this.meaning = _meaning;
    		this.wordStr = _wordStr;
    		this.meanStr = _meanStr;
    	}
    };
    
	private class LoadDataTask extends AsyncTask<Void, Void, Boolean> {
		private boolean loadResult = false;
		private String dbname;
		
		@Override
		protected void onPreExecute() {
			super.onPreExecute();
	    	buttonSearch.setEnabled(false);
		}

		@Override
		protected Boolean doInBackground(Void... params) {
			try {
				dbname = DictionaryDatabase.copyDatabase(CKanjiActivity.this); 
				if (dbname != null) {
					loadResult = true;
				} else {
					loadResult = false;
				}
			} catch (Throwable e) {
				e.printStackTrace();
				return false;
			}
			return true;
		}
		
		@Override
		protected void onPostExecute(Boolean result) {
			if (result == true && !CKanjiActivity.this.isFinishing()) {
				if (loadResult) {
					dataBaseFileName = dbname;
					showSearchLoadingSuccess();
				} else {
					dataBaseFileName = null;
					showSearchLoadingFailed();
				}
			} else if (result == false) {
				dataBaseFileName = null;
				finish();
			}
		}
    }
	
	private class SearchTask extends AsyncTask<String, Void, Boolean> {
		private boolean loadResult = false;
		private int resultNum = 0;
		private String keyword = "";
		private int type = SEARCH_TYPE_PREFIX;
		
		@Override
		protected void onPreExecute() {
			super.onPreExecute();
			buttonSearch.setEnabled(false);
			tableViewSearch.clear();
			wordItems.clear();
			showSearchStart();
		}

		@Override
		protected Boolean doInBackground(String... params) {
			if (params[0] != null) {
				keyword = params[0];
			} else {
				keyword = "";
			}
			try {
				type = Integer.parseInt(params[1]);
			} catch (Throwable e) {
				e.printStackTrace();
			}
			try {
				SQLiteDatabase db = null;
				boolean result = true;
				String dbPath = dataBaseFileName;
				try {
					db = SQLiteDatabase.openDatabase(dbPath, 
						null, 
						SQLiteDatabase.OPEN_READONLY | SQLiteDatabase.NO_LOCALIZED_COLLATORS);
					Cursor cursor = null;
					String selection = null;
					String[] selectionArgs = null;
					String[] columns = null;
					switch(type) {
					case SEARCH_TYPE_PREFIX:
						selection = DictionaryOpenHelper.KEY_WORD + " LIKE ?" + " OR " + 
								DictionaryOpenHelper.KEY_WORD2 + " LIKE ?" + " OR " +
								DictionaryOpenHelper.KEY_READING + " LIKE ?";
						selectionArgs = new String[]{keyword + "%", keyword + "%", keyword + "%"};
						break;
						
					case SEARCH_TYPE_INFIX:
						selection = DictionaryOpenHelper.KEY_WORD + " LIKE ?" + " OR " + 
								DictionaryOpenHelper.KEY_WORD2 + " LIKE ?" + " OR " +
								DictionaryOpenHelper.KEY_READING + " LIKE ?";
						selectionArgs = new String[]{"%" + keyword + "%", "%" + keyword + "%", "%" + keyword + "%"};
						break;
					
					case SEARCH_TYPE_SUFFIX:
						selection = DictionaryOpenHelper.KEY_WORD + " LIKE ?" + " OR " +
								DictionaryOpenHelper.KEY_WORD2 + " LIKE ?" + " OR " +
								DictionaryOpenHelper.KEY_READING + " LIKE ?";
						selectionArgs = new String[]{"%" + keyword, "%" + keyword, "%" + keyword};
						break;
						
					case SEARCH_TYPE_FULLTEXT:
						selection = DictionaryOpenHelper.KEY_WORD + " LIKE ?" + " OR " +
								DictionaryOpenHelper.KEY_WORD2 + " LIKE ?" + " OR " +
								DictionaryOpenHelper.KEY_READING + " LIKE ?" + " OR " +
								DictionaryOpenHelper.KEY_DEFINITION + " LIKE ?";
						selectionArgs = new String[]{"%" + keyword + "%", "%" + keyword + "%", "%" + keyword + "%", "%" + keyword + "%"};
						break;
					}
					columns = new String[]{
						DictionaryOpenHelper.KEY_WORD, 
						DictionaryOpenHelper.KEY_DEFINITION,
						DictionaryOpenHelper.KEY_READING,
						DictionaryOpenHelper.KEY_TYPE,
					};
					cursor = db.query(false, //destinct
							DictionaryOpenHelper.FTS_VIRTUAL_TABLE, //table
							columns, //columns
							selection, //"word LIKE ?", //selection
							selectionArgs, //new String[]{"%明日%"}, //selectionArgs
							null, //groupBy
							null, //having
							DictionaryOpenHelper.KEY_READING + " ASC", //orderBy
							null); //"0, 10"); //limit
					try {
						resultNum = 0;
						while (cursor.moveToNext()) {
							String word = cursor.getString(0);
							String meaning = cursor.getString(1);
							String reading = cursor.getString(2);
							String type = cursor.getString(3);
							String wordStr = "";
							if (word != null && word.length() > 0) {
								wordStr += word;
							}
							if (wordStr.length() > 0) {
								if (reading != null && reading.length() > 0) {
									wordStr += "【" + reading + "】";
								}
							} else {
								if (reading != null && reading.length() > 0) {
									wordStr = reading;
								}
							}
							String meanStr = "";
							if (type != null && type.length() > 0) {
								meanStr +=  "【" + type + "】\n";
							}
							if (meaning != null && meaning.length() > 0) {
								meanStr += meaning;
							}
							wordItems.add(new WordItem(word, meaning, reading, type, wordStr, meanStr));
							tableViewSearch.addBasicItem(wordStr, meanStr);
							resultNum++;
						}
					} catch (Throwable e) {
						e.printStackTrace();
						result = false;
					} finally {
						if (cursor != null) {
							cursor.close();
						}
					}
				} catch (Throwable e) {
					e.printStackTrace();
					result = false;
				} finally {
					if (db != null) {
						db.close();
					} 
				}
				loadResult = result;
			} catch (Throwable e) {
				e.printStackTrace();
				return false;
			}
			return true;
		}
		
		@Override
		protected void onPostExecute(Boolean result) {
			if (result == true && !CKanjiActivity.this.isFinishing()) {
				tableViewSearch.commit();
				buttonSearch.setEnabled(true);
				tableViewSearch.requestFocus();
				tableViewSearch.requestFocusFromTouch();
				if (loadResult) {
					showSearchEnd(keyword, resultNum);
					if (resultNum > 0) {
						InputMethodManager inputMethodManager = (InputMethodManager) getSystemService(Context.INPUT_METHOD_SERVICE);
						inputMethodManager.hideSoftInputFromWindow(editTextInput.getWindowToken(), 0);
					}
				} else {
					wordItems.clear();
					showSearchFailed();
				}
			} else if (result == false) {
				wordItems.clear();
				dataBaseFileName = null;
				finish();
			}
			searchTask = null;
			tableViewSearch.invalidate();
		}
    }
}

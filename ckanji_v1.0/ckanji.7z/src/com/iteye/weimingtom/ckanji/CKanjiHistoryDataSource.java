package com.iteye.weimingtom.ckanji;

import java.util.ArrayList;
import java.util.List;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.SQLException;
import android.database.sqlite.SQLiteDatabase;
import android.text.format.Time;
import android.util.Log;

public class CKanjiHistoryDataSource {
	private final static boolean D = false;
	private final static String TAG = "CKanjiHistoryDataSource";
	
	private SQLiteDatabase database;
	private CKanjiHistorySQLiteOpenHelper dbHelper;

	private final String[] allColumns = { 
		CKanjiHistorySQLiteOpenHelper.COLUMN_ID,
		CKanjiHistorySQLiteOpenHelper.COLUMN_CONTENT, 
	};

	public CKanjiHistoryDataSource(Context context) {
		dbHelper = new CKanjiHistorySQLiteOpenHelper(context);
	}
	
	public void open() throws SQLException {
		database = dbHelper.getWritableDatabase();
	}
	
	public void close() {
		if (database != null) {
			database.close();
			database = null;
		}
		if (dbHelper != null) {
			dbHelper.close();
			dbHelper = null;
		}
	}

	public long createItem(CKanjiHistoryItem item) {
		Time currTime = new Time(Time.getCurrentTimezone());
		currTime.setToNow();
		item.setPlainTime(currTime);
		ContentValues values = new ContentValues();
		long insertId;
		values.put(CKanjiHistorySQLiteOpenHelper.COLUMN_CONTENT, item.getContent());
		if (item.getId() < 0) {
			insertId = database.insert(CKanjiHistorySQLiteOpenHelper.TABLE_HISTORY, 
				null, values);
			if (D) {
				Log.d(TAG, "insert(" + item.getId() + "," + insertId + ") " + item);
			}
			return insertId;
		} else {
			insertId = item.getId();
			database.update(CKanjiHistorySQLiteOpenHelper.TABLE_HISTORY,
				values, 
				CKanjiHistorySQLiteOpenHelper.COLUMN_ID + " = " + insertId, 
				null);
			if (D) {
				Log.d(TAG, "update(" + item.getId() + "," + insertId + ") " + item);
			}
			return insertId;
		}
	}

	private CKanjiHistoryItem cursorToItem(Cursor cursor) {
		CKanjiHistoryItem content = new CKanjiHistoryItem();
		content.setId(cursor.getLong(0));
		content.setContent(cursor.getString(1));
		return content;
	}

	public void deleteItem(CKanjiHistoryItem content) {
		long id = content.getId();
		database.delete(CKanjiHistorySQLiteOpenHelper.TABLE_HISTORY, 
			CKanjiHistorySQLiteOpenHelper.COLUMN_ID + " = " + id, null);
	}

	public void deleteAllItem() {
		database.delete(CKanjiHistorySQLiteOpenHelper.TABLE_HISTORY, 
			null, null);
	}
	
	public ArrayList<CKanjiHistoryItem> getAllItems() {
		ArrayList<CKanjiHistoryItem> contents = new ArrayList<CKanjiHistoryItem>();
		Cursor cursor = database.query(CKanjiHistorySQLiteOpenHelper.TABLE_HISTORY,
				allColumns, 
				null, null, 
				null, null, 
				CKanjiHistorySQLiteOpenHelper.COLUMN_ID + " ASC");
		cursor.moveToFirst();
		while (!cursor.isAfterLast()) {
			CKanjiHistoryItem content = cursorToItem(cursor);
			contents.add(content);
			cursor.moveToNext();
		}
		cursor.close();
		return contents;
	}
	
	public CKanjiHistoryItem getItemById(long id) {
		CKanjiHistoryItem item = null;
		Cursor cursor = database.query(CKanjiHistorySQLiteOpenHelper.TABLE_HISTORY,
				allColumns, 
				CKanjiHistorySQLiteOpenHelper.COLUMN_ID + " = " + id, null, 
				null, null, null);
		cursor.moveToFirst();
		while (!cursor.isAfterLast()) {
			item = cursorToItem(cursor);
			cursor.moveToNext();
		}
		return item;
	}
}

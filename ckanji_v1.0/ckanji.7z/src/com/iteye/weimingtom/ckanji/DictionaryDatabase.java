package com.iteye.weimingtom.ckanji;

import android.app.SearchManager;
import android.content.Context;
import android.content.res.AssetManager;
import android.content.res.Resources;
import android.database.Cursor;
import android.database.sqlite.SQLiteQueryBuilder;
import android.provider.BaseColumns;
import android.util.Log;
import android.widget.Toast;

import java.io.BufferedInputStream;
import java.io.BufferedOutputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.util.HashMap;

public class DictionaryDatabase {
	private final static boolean D = false;
	private final static String TAG = "DictionaryDatabase";
	
    private final DictionaryOpenHelper mDatabaseOpenHelper;
    private static final HashMap<String, String> mColumnMap = buildColumnMap();

    public DictionaryDatabase(Context context) {
    	if (DictionaryOpenHelper.COPY_DATABASE) {
    		copyDatabase(context);
    	}
        mDatabaseOpenHelper = new DictionaryOpenHelper(context);
    }

    private static HashMap<String,String> buildColumnMap() {
        HashMap<String,String> map = new HashMap<String,String>();
        map.put(DictionaryOpenHelper.KEY_WORD, DictionaryOpenHelper.KEY_WORD);
        map.put(DictionaryOpenHelper.KEY_DEFINITION, DictionaryOpenHelper.KEY_DEFINITION);
        map.put(DictionaryOpenHelper.KEY_READING, DictionaryOpenHelper.KEY_READING);
        map.put(DictionaryOpenHelper.KEY_TYPE, DictionaryOpenHelper.KEY_TYPE);
        map.put(BaseColumns._ID, "rowid AS " + BaseColumns._ID);
        map.put(SearchManager.SUGGEST_COLUMN_INTENT_DATA_ID, "rowid AS " + SearchManager.SUGGEST_COLUMN_INTENT_DATA_ID);
        map.put(SearchManager.SUGGEST_COLUMN_SHORTCUT_ID, "rowid AS " + SearchManager.SUGGEST_COLUMN_SHORTCUT_ID);
        return map;
    }

    public Cursor getWord(String rowId, String[] columns) {
        String selection = "rowid = ?";
        String[] selectionArgs = new String[] {rowId};
        return query(selection, selectionArgs, columns);
    }

    public Cursor getWordMatches(String query, String[] columns) {
        String selection = DictionaryOpenHelper.KEY_WORD + " LIKE ?" + " OR " + 
        		DictionaryOpenHelper.KEY_READING + " LIKE ?";
        String[] selectionArgs = new String[] {"%" + query + "%", "%" + query + "%"};
        return query(selection, selectionArgs, columns);
    }

    private Cursor query(String selection, String[] selectionArgs, String[] columns) {
        SQLiteQueryBuilder builder = new SQLiteQueryBuilder();
        builder.setTables(DictionaryOpenHelper.FTS_VIRTUAL_TABLE);
        builder.setProjectionMap(mColumnMap);
        Cursor cursor = builder.query(mDatabaseOpenHelper.getReadableDatabase(),
        	columns, selection, selectionArgs, 
        	null, null, null);
        if (cursor == null) {
            return null;
        } else if (!cursor.moveToFirst()) {
            cursor.close();
            return null;
        }
        return cursor;
    }
    
    public static String copyDatabase(Context context) {
    	if (D) {
    		Log.d(TAG, "Copying words...");
    	}
    	String dbname = DictionaryOpenHelper.createExternalDatabase(context);
    	if (dbname != null) {
	    	final AssetManager assetManager = context.getAssets();
	    	InputStream inputStream = null;
	        BufferedInputStream istr = null; 
	        OutputStream outputStream = null;
	        BufferedOutputStream ostr = null;
	        try {
	        	if (DictionaryOpenHelper.COPY_DATABASE) {
	        		inputStream = assetManager.open("dict_db.ogg");
	        	} else {
	        		inputStream = assetManager.open("dict_db_.ogg");
	        	}
	        	istr = new BufferedInputStream(inputStream);
	        	outputStream = new FileOutputStream(dbname);
	        	ostr = new BufferedOutputStream(outputStream);
	        	byte[] bytes = new byte[2048];
	            int size = 0;
	            while (true) {
	                size = istr.read(bytes);
	                if (size >= 0) {
	                	ostr.write(bytes, 0, size);
	                	ostr.flush();
	                } else {
	                	break;
	                }
	            }
	            return dbname;
	        } catch (IOException e) {
		        if (D) {
		        	Log.e(TAG, "copying words error!!!");
		        }
	        	e.printStackTrace();
	        } finally {
	        	if (ostr != null) {
	        		try {
	        			ostr.close();
					} catch (IOException e) {
						e.printStackTrace();
					}
	        	}
	        	if (outputStream != null) {
	        		try {
	        			outputStream.close();
					} catch (IOException e) {
						e.printStackTrace();
					}
	        	}
	        	if (istr != null) {
		        	try {
						istr.close();
					} catch (IOException e) {
						e.printStackTrace();
					}
	        	}
	        	if (inputStream != null) {
		        	try {
		        		inputStream.close();
					} catch (IOException e) {
						e.printStackTrace();
					}
	        	}
		        if (D) {
		        	Log.d(TAG, "DONE copying words.");
		        }
	        }
    	} else {
	        if (D) {
	        	Log.e(TAG, "copying words error!!!");
	        }	
    	}
    	return null;
    }
}

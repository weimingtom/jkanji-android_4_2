package com.iteye.weimingtom.ckanji;

import android.app.Activity;
import android.app.SearchManager;
import android.content.Intent;
import android.database.Cursor;
import android.net.Uri;
import android.os.Bundle;
import android.util.Log;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ListView;
import android.widget.SimpleCursorAdapter;
import android.widget.TextView;
import android.widget.AdapterView.OnItemClickListener;

public class SearchableDictionary extends Activity {
	private final static boolean D = false;
	private final static String TAG = "SearchableDictionary";
	
	private final static int MENU_SEARCH = Menu.FIRST;
	
    private TextView mTextView;
    private ListView mListView;

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.search);
        mTextView = (TextView) findViewById(R.id.text);
        mListView = (ListView) findViewById(R.id.list);
        
        Intent intent = this.getIntent();
        if (Intent.ACTION_VIEW.equals(intent.getAction())) {
            Intent wordIntent = new Intent(this, WordActivity.class);
            wordIntent.setData(intent.getData());
            startActivity(wordIntent);
            finish();
        } else if (Intent.ACTION_SEARCH.equals(intent.getAction())) {
            String query = intent.getStringExtra(SearchManager.QUERY);
            showResults(query);
        }
    }

    private void showResults(String query) {
        Cursor cursor = managedQuery(DictionaryProvider.CONTENT_URI, 
        		null, null, new String[] {query}, null);
        if (cursor == null) {
            mTextView.setText("没找到结果：" + query);
        } else {
            int count = cursor.getCount();
            mTextView.setText("搜索结果" + count + "条：" + query);
            String[] from = new String[] { 
            	DictionaryOpenHelper.KEY_WORD,
            	DictionaryOpenHelper.KEY_DEFINITION 
            };
            int[] to = new int[] { 
            	R.id.word,
                R.id.definition 
            };
            SimpleCursorAdapter words = new SimpleCursorAdapter(this,
            		R.layout.result, cursor, from, to);
            mListView.setAdapter(words);
            mListView.setOnItemClickListener(new OnItemClickListener() {
            	@Override
                public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                    Intent wordIntent = new Intent(SearchableDictionary.this, WordActivity.class);
                    Uri data = Uri.withAppendedPath(DictionaryProvider.CONTENT_URI, String.valueOf(id));
                    wordIntent.setData(data);
                    startActivity(wordIntent);
                }
            });
        }
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        menu.add(0, MENU_SEARCH, 0, "搜索").setIcon(android.R.drawable.ic_menu_search);
    	return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        switch (item.getItemId()) {
        case MENU_SEARCH:
        	if (D) {
        		Log.e(TAG, "onOptionsItemSelected");
        	}
            onSearchRequested();
            return true;
        }
        return false;
    }
}

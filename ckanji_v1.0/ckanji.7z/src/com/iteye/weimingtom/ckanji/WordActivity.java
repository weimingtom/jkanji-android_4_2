package com.iteye.weimingtom.ckanji;

import android.app.Activity;
import android.database.Cursor;
import android.net.Uri;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;
import android.widget.TextView;
import android.widget.Toast;

public class WordActivity extends Activity {
	private final static int MENU_SEARCH = Menu.FIRST;
	
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        this.setContentView(R.layout.word);
        
        Uri uri = getIntent().getData();
        Cursor cursor = managedQuery(uri, null, null, null, null);
        if (cursor == null) {
        	Toast.makeText(WordActivity.this, "找不到结果", Toast.LENGTH_SHORT).show();
            finish();
        } else {
            cursor.moveToFirst();
            TextView word = (TextView) findViewById(R.id.word);
            TextView definition = (TextView) findViewById(R.id.definition);
            int wIndex = cursor.getColumnIndexOrThrow(DictionaryOpenHelper.KEY_WORD);
            int dIndex = cursor.getColumnIndexOrThrow(DictionaryOpenHelper.KEY_DEFINITION);
            word.setText(cursor.getString(wIndex));
            definition.setText(cursor.getString(dIndex));
        }
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        menu.add(0, MENU_SEARCH, 0, "搜索").setIcon(android.R.drawable.ic_menu_search);
    	return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        switch (item.getItemId()) {
        case MENU_SEARCH:
            onSearchRequested();
            return true;
        }
        return false;
    }
}

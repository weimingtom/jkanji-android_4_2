package com.iteye.weimingtom.ckanji;

import java.io.BufferedInputStream;
import java.io.BufferedOutputStream;
import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.io.OutputStreamWriter;
import java.util.ArrayList;

import com.csvreader.CsvReader;
import com.csvreader.CsvWriter;

import br.com.dina.ui.model.BasicItem;
import br.com.dina.ui.widget.UITableView;
import br.com.dina.ui.widget.UITableView.ClickListener;
import android.app.Activity;
import android.app.AlertDialog;
import android.app.Dialog;
import android.content.ActivityNotFoundException;
import android.content.Context;
import android.content.DialogInterface;
import android.content.DialogInterface.OnCancelListener;
import android.content.DialogInterface.OnShowListener;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.SharedPreferences.Editor;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.net.Uri;
import android.os.AsyncTask;
import android.os.Bundle;
import android.text.ClipboardManager;
import android.text.format.Time;
import android.util.Log;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.inputmethod.InputMethodManager;
import android.widget.AdapterView;
import android.widget.AdapterView.OnItemSelectedListener;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.CompoundButton;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.LinearLayout;
import android.widget.RelativeLayout;
import android.widget.TextView;
import android.widget.Toast;
import android.widget.ViewFlipper;
import android.widget.CompoundButton.OnCheckedChangeListener;
//import android.widget.RadioButton;

/**
 * CuteKanji
 * @author weimingtom
 * @see https://github.com/ling0322/danci
 * @see http://blog.csdn.net/billpig/article/details/6634481
 * @see http://vndb.org/v1657
 * @see http://stackoverflow.com/questions/6100034/setting-image-source-for-togglebutton
 * @see http://developer.android.com/guide/topics/resources/drawable-resource.html#LayerList
 * 
 */

//android.R.anim.fade_in;
//android.R.anim.fade_out;
//android.R.anim.slide_in_left;
//android.R.anim.slide_out_right;
public class CKanjiActivity extends Activity {
	private final static boolean D = false;
	private final static String TAG = "CKanjiActivity";
	
	public final static String EXTRA_KEYWORD = "CKanjiActivity.EXTRA_KEYWORD";
	
	private static final String SHARE_PREF_NAME = "pref";
	private static final String SHARE_PREF_SEARCH_TYPE = "searchType";
	private static final String SHARE_PREF_UI_TYPE = "uiType";
	private static final String SHARE_PREF_FAV_TYPE = "favType";
	
	private static final int REQUEST_FAV_EDIT = 1000;
	
	//setDisplayedChild
	//getDisplayedChild
	//TODO: mFlipper's layer
	private final static int PAGE_SEARCH = 0;
	private final static int PAGE_DETAIL = 1;
	private final static int PAGE_HISTORY = 2;
	private final static int PAGE_FAVOURITE = 3;
	private final static int PAGE_SETTINGS = 4;

	private final static int DIALOG_LIST_SEARCH = 1;
	private final static int DIALOG_LIST_UI = 2;
	private final static int DIALOG_CLEAR_HISTORY = 3;
	private final static int DIALOG_CLEAR_FAVOURITE = 4;
	private final static int DIALOG_EXIT = 5;
	private final static int DIALOG_LIST_FAV = 6;
	private final static int DIALOG_BACKUP_FAV_DB = 7;
	private final static int DIALOG_RESUME_FAV_DB = 8;
	private final static int DIALOG_BACKUP_FAV_CSV = 9;
	private final static int DIALOG_RESUME_FAV_CSV = 10;
	
	public final static int SEARCH_TYPE_PREFIX = 0;
	public final static int SEARCH_TYPE_SUFFIX = 1;
	public final static int SEARCH_TYPE_INFIX = 2;
	public final static int SEARCH_TYPE_FULLTEXT = 3;
	public final static int SEARCH_TYPE_FULL = 4;
	private final static String[] SEARCH_TYPE_ITEMS = new String[] {
		"前缀",
		"后缀",
		"包含",
		"全文",
		"精确",
	};
	public final static int UI_TYPE_DEFAULT = 0;
	public final static int UI_TYPE_CAT = 1;
	private final static String[] UI_TYPE_ITEMS = new String[] {
		"默认（紫色）",
		"変態王子と笑わない猫（褐色）",
	};
	public final static int FAV_TYPE_VIEW = 0;
	public final static int FAV_TYPE_EDIT = 1;
	private final static String[] FAV_TYPE_ITEMS = new String[] {
		"查看",
		"编辑",
	};
	
	private EditText editTextInput;
	private ImageButton imageButtonInputClear;
	private Button buttonSearch;
	private Button buttonTitle1, buttonTitle2;
	private UITableView tableViewSearchStatus, tableViewSearch, tableViewDetail, tableViewHistory, tableViewFavourite, tableViewSettings, tableViewBackup, tableViewAbout;
	private CheckBox checkBoxSearch, checkBoxDetail, checkBoxHistory, checkBoxFavourite, checkBoxSettings;
	private ViewFlipper mFlipper;
	private TextView textViewTitle;
	
	private LinearLayout linearLayoutTop;
	private RelativeLayout titleBar;
	private LinearLayout roundedTextBar;
	private LinearLayout rg_index;
	
	
	private String dataBaseFileName;
	private SearchTask searchTask;
	private ArrayList<WordItem> wordItems;
	private int currentWordItem = -1;
	
	private CKanjiHistoryDataSource hisDataSrc;
	private CKanjiFavouriteDataSource favDataSrc;
	private ArrayList<CKanjiHistoryItem> historyItems;
	private ArrayList<CKanjiFavouriteItem> favouriteItems;
	
	private String queryKeyword;
	private ArrayAdapter<String> resumeFavDBAdapter, resumeFavCSVAdapter;
	
    /** Called when the activity is first created. */
    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.main);
        
        editTextInput = (EditText) findViewById(R.id.editTextInput);
        imageButtonInputClear = (ImageButton) findViewById(R.id.imageButtonInputClear);
        buttonSearch = (Button) findViewById(R.id.buttonSearch);
        buttonTitle1 = (Button) findViewById(R.id.buttonTitle1);
        buttonTitle2 = (Button) findViewById(R.id.buttonTitle2);
        checkBoxSearch = (CheckBox) findViewById(R.id.checkBoxSearch);
        checkBoxDetail = (CheckBox) findViewById(R.id.checkBoxDetail);
        checkBoxHistory = (CheckBox) findViewById(R.id.checkBoxHistory);
        checkBoxFavourite = (CheckBox) findViewById(R.id.checkBoxFavourite);
        checkBoxSettings = (CheckBox) findViewById(R.id.checkBoxSettings);
        mFlipper = (ViewFlipper) this.findViewById(R.id.flipper);
        tableViewSearchStatus = (UITableView) findViewById(R.id.tableViewSearchStatus);
        tableViewSearch = (UITableView) findViewById(R.id.tableViewSearch);   
        tableViewDetail = (UITableView) findViewById(R.id.tableViewDetail);
        tableViewHistory = (UITableView) findViewById(R.id.tableViewHistory);   
        tableViewFavourite = (UITableView) findViewById(R.id.tableViewFavourite);
        tableViewSettings = (UITableView) findViewById(R.id.tableViewSettings);   
        tableViewBackup = (UITableView) findViewById(R.id.tableViewBackup);
        tableViewAbout = (UITableView) findViewById(R.id.tableViewAbout);
        textViewTitle = (TextView) findViewById(R.id.textViewTitle);
        
        linearLayoutTop = (LinearLayout) findViewById(R.id.linearLayoutTop);
        titleBar = (RelativeLayout) findViewById(R.id.titleBar);
        roundedTextBar = (LinearLayout) findViewById(R.id.roundedTextBar);
        rg_index = (LinearLayout) findViewById(R.id.rg_index);
        
        wordItems = new ArrayList<WordItem>();
        resumeFavDBAdapter = new ArrayAdapter<String>(this, 
        		android.R.layout.select_dialog_item);
        resumeFavCSVAdapter = new ArrayAdapter<String>(this, 
        		android.R.layout.select_dialog_item);
        
        buttonTitle1.setText("退出");
        buttonTitle2.setText(getCurrentSearchType());
        textViewTitle.setText("日语词汇向导");
        
    	if (getLastUIType(this) == UI_TYPE_CAT) {
    		linearLayoutTop.setBackgroundResource(R.drawable.bgpattern);
    		titleBar.setBackgroundResource(R.drawable.bar_top2);
    		roundedTextBar.setBackgroundResource(R.drawable.rounded_text_field_bar_top2);
    		rg_index.setBackgroundResource(R.drawable.uitabview_index_tab_tb_bg2);
    	} else {
    		linearLayoutTop.setBackgroundColor(0xffd3d3d3);
    		titleBar.setBackgroundResource(R.drawable.bar_top);
    		roundedTextBar.setBackgroundResource(R.drawable.rounded_text_field_bar_top);
    		rg_index.setBackgroundResource(R.drawable.uitabview_index_tab_tb_bg);
    	}
        
        imageButtonInputClear.setOnClickListener(new OnClickListener() {
			@Override
			public void onClick(View v) {
				editTextInput.setText("");
				editTextInput.requestFocus();
				InputMethodManager imm = (InputMethodManager)
						getSystemService(Context.INPUT_METHOD_SERVICE);
				imm.showSoftInput(editTextInput, 0);
			}
        });
        buttonSearch.setOnClickListener(new OnClickListener() {
			@Override
			public void onClick(View v) {
				startSearch(true);
			}
        });
        buttonTitle1.setOnClickListener(new OnClickListener() {
			@Override
			public void onClick(View v) {
				switch (mFlipper.getDisplayedChild()) {
				case PAGE_SEARCH:
					clearSearchInput();
					finish();
					break;
					
				case PAGE_DETAIL:
					break;
				
				case PAGE_HISTORY:
					showDialog(DIALOG_CLEAR_HISTORY);
					break;
					
				case PAGE_FAVOURITE:
					showDialog(DIALOG_CLEAR_FAVOURITE);
					break;
					
				case PAGE_SETTINGS:
					break;
				}
			}
        });
        buttonTitle2.setOnClickListener(new OnClickListener() {
			@Override
			public void onClick(View v) {
				switch (mFlipper.getDisplayedChild()) {
				case PAGE_SEARCH:
					showDialog(DIALOG_LIST_SEARCH);
					break;
				
				case PAGE_DETAIL:
					break;
					
				case PAGE_HISTORY:
		    		break;
		    		
				case PAGE_FAVOURITE:
					if (false) {
						showDialog(DIALOG_LIST_FAV);
					} else {
						setLastFavType(CKanjiActivity.this, nextFavouriteType());
						updateFavType();
			    		switch (getLastFavType(CKanjiActivity.this)) {
			    		default:
			    		case FAV_TYPE_VIEW :
			    			textViewTitle.setText("生字笔记");
			    			break;
			    			
			    		case FAV_TYPE_EDIT:
			    			textViewTitle.setText("生字笔记编辑");
			    			break;
			    		}
					}
					break;
					
				case PAGE_SETTINGS:
					break;
				}
			}
        });
        checkBoxSearch.setOnCheckedChangeListener(new OnCheckedChangeListener() {
			@Override
			public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
				if (isChecked) {
					flipPage(PAGE_SEARCH);
					buttonTitle1.setVisibility(Button.VISIBLE);
					buttonTitle1.setText("退出");
					buttonTitle2.setVisibility(Button.VISIBLE);
				    buttonTitle2.setText(getCurrentSearchType());
				} else if (mFlipper.getDisplayedChild() == PAGE_SEARCH) {
					flipPage(PAGE_SEARCH);
					clearSearchInput();
				}
			}
        });
        checkBoxDetail.setOnCheckedChangeListener(new OnCheckedChangeListener() {
			@Override
			public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
				if (isChecked) {
					flipPage(PAGE_DETAIL);
					buttonTitle1.setVisibility(Button.INVISIBLE);
					buttonTitle2.setVisibility(Button.INVISIBLE);
					InputMethodManager inputMethodManager = (InputMethodManager) getSystemService(Context.INPUT_METHOD_SERVICE);
					inputMethodManager.hideSoftInputFromWindow(editTextInput.getWindowToken(), 0);	
				} else if (mFlipper.getDisplayedChild() == PAGE_DETAIL) {
					flipPage(PAGE_DETAIL);
				}
			}
        });
        checkBoxHistory.setOnCheckedChangeListener(new OnCheckedChangeListener() {
			@Override
			public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
				if (isChecked) {
					flipPage(PAGE_HISTORY);
					buttonTitle1.setVisibility(Button.VISIBLE);
					buttonTitle1.setText("清空");
					buttonTitle2.setVisibility(Button.INVISIBLE);
					InputMethodManager inputMethodManager = (InputMethodManager) getSystemService(Context.INPUT_METHOD_SERVICE);
					inputMethodManager.hideSoftInputFromWindow(editTextInput.getWindowToken(), 0);
				} else if (mFlipper.getDisplayedChild() == PAGE_HISTORY) {
					flipPage(PAGE_HISTORY);
				}
			}
        });
        checkBoxFavourite.setOnCheckedChangeListener(new OnCheckedChangeListener() {
			@Override
			public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
				if (queryKeyword != null) {
					finish();
					return;
				}
				if (isChecked) {
					flipPage(PAGE_FAVOURITE);
					buttonTitle1.setVisibility(Button.VISIBLE);
					buttonTitle1.setText("清空");
					buttonTitle2.setVisibility(Button.VISIBLE);
					buttonTitle2.setText(getCurrentFavouriteType());
					InputMethodManager inputMethodManager = (InputMethodManager) getSystemService(Context.INPUT_METHOD_SERVICE);
					inputMethodManager.hideSoftInputFromWindow(editTextInput.getWindowToken(), 0);
				} else if (mFlipper.getDisplayedChild() == PAGE_FAVOURITE) {
					flipPage(PAGE_FAVOURITE);
				}
			}
        });
        checkBoxSettings.setOnCheckedChangeListener(new OnCheckedChangeListener() {
			@Override
			public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
				if (isChecked) {
					flipPage(PAGE_SETTINGS);
					buttonTitle1.setVisibility(Button.INVISIBLE);
					buttonTitle2.setVisibility(Button.INVISIBLE);
					InputMethodManager inputMethodManager = (InputMethodManager) getSystemService(Context.INPUT_METHOD_SERVICE);
					inputMethodManager.hideSoftInputFromWindow(editTextInput.getWindowToken(), 0);
				} else if (mFlipper.getDisplayedChild() == PAGE_SETTINGS) {
					flipPage(PAGE_SETTINGS);
				}
			}
        });
        
        showSearchLoadingStart();
        tableViewSearchStatus.setClickListener(new ClickListener() {
    		@Override
    		public void onClick(int index) {
    			if (!buttonSearch.isEnabled()) {
    				//重试
    				new LoadDataTask().execute();
    			} else {
    				
    			}
    		}
        });
        tableViewSearch.setClickListener(new ClickListener() {
    		@Override
    		public void onClick(int index) {
    			//shareTable(index);
    			updateDetail(index);
    		}
        });
        
		Intent intent = getIntent();
		if (intent != null) {
			queryKeyword = intent.getStringExtra(EXTRA_KEYWORD);
		}
        
        buttonSearch.postDelayed(new Runnable() {
			@Override
			public void run() {
				if (queryKeyword != null) {
					dataBaseFileName = DictionaryDatabase.copyDatabase(CKanjiActivity.this);
					editTextInput.setText("");
					editTextInput.append(queryKeyword);
					startSearchFull(false);
				} else {
					new LoadDataTask().execute();
				}
			}
        }, 500);
        
        tableViewHistory.setClickListener(new ClickListener() {
    		@Override
    		public void onClick(int index) {
    			if (historyItems != null && index >= 0 && index < historyItems.size()) {
    				CKanjiHistoryItem item = historyItems.get(historyItems.size() - 1 - index);
    				String desc = item.getPlainDesc();
    				editTextInput.setText("");
    				editTextInput.append(desc);
    				flipPage(PAGE_SEARCH);
    				startSearch(false);
    			}
    		}
        });
        updateHistory();

        tableViewFavourite.setClickListener(new ClickListener() {
    		@Override
    		public void onClick(int index) {
    			switch (getLastFavType(CKanjiActivity.this)) {
    			case FAV_TYPE_VIEW:
	    			if (favouriteItems != null && index >= 0 && index < favouriteItems.size()) {
	    				CKanjiFavouriteItem item = favouriteItems.get(favouriteItems.size() - 1 - index);
	    				String word1 = item.getPlainWord1();
	    				String word2 = item.getPlainWord2();
	    				editTextInput.setText("");
	    				if (word1 != null && word1.length() > 0) {
	    					editTextInput.append(word1);
	    				} else if (word2 != null && word2.length() > 0){
	    					editTextInput.append(word2);
	    				} else {
	    					Toast.makeText(CKanjiActivity.this, 
	    						"关键词为空", 
	    						Toast.LENGTH_SHORT).show();
	    				}
	    				flipPage(PAGE_SEARCH);
	    				startSearchFull(false);
	    			}
	    			break;
	    			
    			case FAV_TYPE_EDIT:
	    			if (favouriteItems != null && index >= 0 && index < favouriteItems.size()) {
	    				CKanjiFavouriteItem item = favouriteItems.get(favouriteItems.size() - 1 - index);
	    				if (item != null) {
		    				startActivityForResult(new Intent(CKanjiActivity.this, CKanjiEditActivity.class)
		    					.putExtra(CKanjiEditActivity.EXTRA_FAV_ID, item.getId()), 
		    					REQUEST_FAV_EDIT
		    				);
	    				}
	    			}
    				break;
    			}
    		}
        });
        updateFavourite();
        
    	updateSettings();
    	tableViewSettings.setClickListener(new ClickListener() {
    		@Override
    		public void onClick(int index) {
    			switch (index) {
    			case 1:
    				//setLastSearchType(nextSearchType());
    				showDialog(DIALOG_LIST_SEARCH);
    				break;
    				
    			case 2:
    				showDialog(DIALOG_LIST_UI);
    				break;
    				
    			case 3:
    				new LoadDataTask().execute();
    				break;
    			}
//    			updateSettings();
    		}
        });
    	updateBackup();
    	tableViewBackup.setClickListener(new ClickListener() {
    		@Override
    		public void onClick(int index) {
    			switch (index) {
    			case 1:
    				showDialog(DIALOG_BACKUP_FAV_DB);
    				break;
    				
    			case 2:
    				showDialog(DIALOG_RESUME_FAV_DB);
    				break;
    				
    			case 3:
    				shareFavourite();
    				break;
    				
    			case 4:
    				showDialog(DIALOG_BACKUP_FAV_CSV);
    				break;
    				
    			case 5:
    				showDialog(DIALOG_RESUME_FAV_CSV);
    				break;
    			}
    		}
        });
    	
    	updateAbout();
    	tableViewAbout.setClickListener(new ClickListener() {
    		@Override
    		public void onClick(int index) {
    			switch (index) {
    			case 5:
    				openBlog();
    				break;
    			
    			case 6:
    				sendEmail();
    				break;
    			}
    		}
        });
    	
    	tableViewDetail.setClickListener(new ClickListener() {
    		@Override
    		public void onClick(int index) {
    			shareWord(index);
    		}
        });
    }
    
    private void clearSearchInput() {
		if (searchTask == null) {
			flipPage(PAGE_SEARCH);
			editTextInput.setText("");
			editTextInput.requestFocus();
			InputMethodManager imm = (InputMethodManager)
					getSystemService(Context.INPUT_METHOD_SERVICE);
			imm.showSoftInput(editTextInput, 0);
			tableViewSearch.clear();
			tableViewSearch.commit();
		}
    }
    
    private void flipPage(int page) {
    	if (mFlipper.getDisplayedChild() != page) {
    		mFlipper.setDisplayedChild(page);
    	}
    	switch (page) {
    	case PAGE_SEARCH:
    		checkBoxSearch.setChecked(true); 
    		checkBoxDetail.setChecked(false); 
    		checkBoxHistory.setChecked(false);
    		checkBoxFavourite.setChecked(false);
    		checkBoxSettings.setChecked(false);
    		textViewTitle.setText("日语词汇向导");
    		break;
    		
    	case PAGE_DETAIL:
    		checkBoxSearch.setChecked(false);
    		checkBoxDetail.setChecked(true); 
    		checkBoxHistory.setChecked(false);
    		checkBoxFavourite.setChecked(false);
    		checkBoxSettings.setChecked(false);
    		textViewTitle.setText("单词释义");
    		break;
    	
    	case PAGE_HISTORY:
    		checkBoxSearch.setChecked(false); 
    		checkBoxDetail.setChecked(false); 
    		checkBoxHistory.setChecked(true);
    		checkBoxFavourite.setChecked(false);
    		checkBoxSettings.setChecked(false);
    		textViewTitle.setText("查询历史");
    		break;
    		
    	case PAGE_FAVOURITE:
    		checkBoxSearch.setChecked(false); 
    		checkBoxDetail.setChecked(false); 
    		checkBoxHistory.setChecked(false);
    		checkBoxFavourite.setChecked(true);
    		checkBoxSettings.setChecked(false);
    		switch (getLastFavType(CKanjiActivity.this)) {
    		default:
    		case FAV_TYPE_VIEW :
    			textViewTitle.setText("生字笔记");
    			break;
    			
    		case FAV_TYPE_EDIT:
    			textViewTitle.setText("生字笔记编辑");
    			break;
    		}
    		break;
    		
    	case PAGE_SETTINGS:
    		checkBoxSearch.setChecked(false); 
    		checkBoxDetail.setChecked(false); 
    		checkBoxHistory.setChecked(false);
    		checkBoxFavourite.setChecked(false);
    		checkBoxSettings.setChecked(true);
    		textViewTitle.setText("设置与关于");
    		break;
    	}
    }
    
    /**
     * @see startSearchFull
     * @param isRecorded
     */
    private void startSearch(boolean isRecorded) {
		String keyword = editTextInput.getText().toString();
		if (searchTask == null && keyword != null && keyword.length() > 0) {
	    	if (isRecorded) {
	    		insertHistory(keyword);
	        	updateHistory();
	    	}
			searchTask = new SearchTask();
			searchTask.execute(keyword, Integer.toString(getLastSearchType(this)));
		} else {
			showSearchKeywordEmpty(getLastSearchType(this));
		}
    }
    
    private void startSearchFull(boolean isRecorded) {
    	String keyword = editTextInput.getText().toString();
		if (searchTask == null && keyword != null && keyword.length() > 0) {
	    	if (isRecorded) {
	    		insertHistory(keyword);
	        	updateHistory();
	    	}
			searchTask = new SearchTask();
			searchTask.execute(keyword, Integer.toString(SEARCH_TYPE_FULL));
		} else {
			showSearchKeywordEmpty(SEARCH_TYPE_FULL);
		}
    }
    
	private void showSearchLoadingStart() {
    	tableViewSearchStatus.clear();
    	tableViewSearchStatus.addBasicItem(new BasicItem("正在复制数据库...", null, false));
    	tableViewSearchStatus.commit();
    }
    
    private void showSearchLoadingSuccess() {
    	if (D) {
    		Log.d(TAG, "showSearchLoadingSuccess");
    	}
    	buttonSearch.setEnabled(true);
    	tableViewSearchStatus.clear();
    	tableViewSearchStatus.addBasicItem(new BasicItem("请输入关键词", null, false));
    	tableViewSearchStatus.commit();
    }
    
    private void showSearchLoadingFailed() {
    	if (D) {
    		Log.d(TAG, "showSearchLoadingFailed");
    	}
    	buttonSearch.setEnabled(false);
    	tableViewSearchStatus.clear();
    	tableViewSearchStatus.addBasicItem(new BasicItem("复制失败，请检查SD卡后重试", null));
    	tableViewSearchStatus.commit();
    }

    private void showSearchStart() {
    	if (D) {
    		Log.d(TAG, "showSearchStart");
    	}
    	buttonSearch.setEnabled(false);
    	tableViewSearchStatus.clear();
    	tableViewSearchStatus.addBasicItem(new BasicItem("搜索中...", null, false));
    	tableViewSearchStatus.commit();
    }

    /**
     * getLastSearchType()
     * @param keyword
     * @param searchType
     * @param count
     */
    private void showSearchEnd(String keyword, int searchType, int count) {
    	if (D) {
    		Log.d(TAG, "showSearchEnd");
    	}
    	tableViewSearchStatus.clear();
    	if (count > 0) {
    		tableViewSearchStatus.addBasicItem(new BasicItem(getSearchTypeString(searchType) + ", 关键词：" + keyword + ", 结果：" + count, null, false));
    	} else {
    		tableViewSearchStatus.addBasicItem(new BasicItem(getSearchTypeString(searchType) + ", 关键词：" + keyword + ", 搜索结果为空", null, false));
    	}
    	tableViewSearchStatus.commit();
    }
    
    /**
     * getLastSearchType(this)
     */
    private void showSearchFailed(int searchType) {
    	if (D) {
    		Log.d(TAG, "showSearchFailed");
    	}
    	buttonSearch.setEnabled(true);
    	tableViewSearchStatus.clear();
    	tableViewSearchStatus.addBasicItem(new BasicItem(getSearchTypeString(searchType) + ", 搜索出错，请检查SD卡上是否已经成功了复制数据库文件或退出后再试", null, false));
    	tableViewSearchStatus.commit();
    }
    
    /**
     * getLastSearchType(this)
     */
    private void showSearchKeywordEmpty(int searchType) {
    	if (D) {
    		Log.d(TAG, "showSearchKeywordEmpty");
    	}
    	buttonSearch.setEnabled(true);
    	tableViewSearchStatus.clear();
    	tableViewSearchStatus.addBasicItem(new BasicItem(getSearchTypeString(searchType) + ", 关键词为空或未完成", null, false));
    	tableViewSearchStatus.commit();
    }
    
    private void backScreen() {
		if (mFlipper.getDisplayedChild() == PAGE_SEARCH) {
//			finish();
			showDialog(DIALOG_EXIT);
		} else {
			flipPage(PAGE_SEARCH);
		}
    }

    @Override
	public void onBackPressed() {
		if (mFlipper.getDisplayedChild() == PAGE_SEARCH) {
			if (queryKeyword != null) {
				super.onBackPressed();
			} else {
				showDialog(DIALOG_EXIT);
			}
		} else {
			flipPage(PAGE_SEARCH);
		}
	}
    
	@Override
	protected void onActivityResult(int requestCode, int resultCode, Intent data) {
		super.onActivityResult(requestCode, resultCode, data);
		if (requestCode == REQUEST_FAV_EDIT) {
			this.updateFavourite();
		}
	}

	@Override
	protected Dialog onCreateDialog(int id) {
    	switch (id) {
        case DIALOG_LIST_SEARCH:
            return new AlertDialog.Builder(this)
                .setTitle("选择匹配方式")
                .setItems(SEARCH_TYPE_ITEMS, new DialogInterface.OnClickListener() {
                    public void onClick(DialogInterface dialog, int which) {
                        setLastSearchType(CKanjiActivity.this, which);
                        updateSearchType();
                    }
                })
                .setNegativeButton("取消", new DialogInterface.OnClickListener() {
					@Override
					public void onClick(DialogInterface dialog, int which) {
						
					}
                })
                .setOnCancelListener(new OnCancelListener() {
					@Override
					public void onCancel(DialogInterface dialog) {
						
					}
                })
                .create();
            
        case DIALOG_LIST_UI:
            return new AlertDialog.Builder(this)
	            .setTitle("选择界面皮肤")
	            .setItems(UI_TYPE_ITEMS, new DialogInterface.OnClickListener() {
	                public void onClick(DialogInterface dialog, int which) {
	                    setLastUIType(CKanjiActivity.this, which);
	                    updateUIType();
	                }
	            })
	            .setNegativeButton("取消", new DialogInterface.OnClickListener() {
					@Override
					public void onClick(DialogInterface dialog, int which) {
						
					}
	            })
	            .setOnCancelListener(new OnCancelListener() {
					@Override
					public void onCancel(DialogInterface dialog) {
						
					}
	            })
	            .create();
            
        case DIALOG_CLEAR_HISTORY:
            return new AlertDialog.Builder(this)
            .setTitle("清除历史")
            .setMessage("是否清除所有历史记录？")
            .setPositiveButton("确定", new DialogInterface.OnClickListener() {
				@Override
				public void onClick(DialogInterface dialog, int which) {
					clearHistory();
				}
            })
            .setNegativeButton("取消", new DialogInterface.OnClickListener() {
				@Override
				public void onClick(DialogInterface dialog, int which) {
					
				}
            })
            .setOnCancelListener(new OnCancelListener() {
				@Override
				public void onCancel(DialogInterface dialog) {
					
				}
            })
            .create();
            
        case DIALOG_CLEAR_FAVOURITE:
            return new AlertDialog.Builder(this)
            .setTitle("清除生字笔记")
            .setMessage("是否清除所有生字笔记？")
            .setPositiveButton("确定", new DialogInterface.OnClickListener() {
				@Override
				public void onClick(DialogInterface dialog, int which) {
					clearFavourite();
				}
            })
            .setNegativeButton("取消", new DialogInterface.OnClickListener() {
				@Override
				public void onClick(DialogInterface dialog, int which) {
					
				}
            })
            .setOnCancelListener(new OnCancelListener() {
				@Override
				public void onCancel(DialogInterface dialog) {
					
				}
            })
            .create();
            
        case DIALOG_EXIT:
            return new AlertDialog.Builder(this)
            .setIcon(R.drawable.ic_launcher)
            .setTitle("日语词汇向导")
            .setMessage("是否退出？")
            .setPositiveButton("确定", new DialogInterface.OnClickListener() {
				@Override
				public void onClick(DialogInterface dialog, int which) {
					finish();
				}
            })
            .setNegativeButton("取消", new DialogInterface.OnClickListener() {
				@Override
				public void onClick(DialogInterface dialog, int which) {
					
				}
            })
            .setOnCancelListener(new OnCancelListener() {
				@Override
				public void onCancel(DialogInterface dialog) {
					
				}
            })
            .create();
            
        case DIALOG_LIST_FAV:
            return new AlertDialog.Builder(this)
	            .setTitle("选择生字笔记模式")
	            .setItems(FAV_TYPE_ITEMS, new DialogInterface.OnClickListener() {
	                public void onClick(DialogInterface dialog, int which) {
	                    setLastFavType(CKanjiActivity.this, which);
	                    updateFavType();
	                }
	            })
	            .setNegativeButton("取消", new DialogInterface.OnClickListener() {
					@Override
					public void onClick(DialogInterface dialog, int which) {
						
					}
	            })
	            .setOnCancelListener(new OnCancelListener() {
					@Override
					public void onCancel(DialogInterface dialog) {
						
					}
	            })
	            .create();
            
        case DIALOG_BACKUP_FAV_DB:
            return new AlertDialog.Builder(this)
	            .setTitle("备份生字笔记数据库")
	            .setMessage("是否备份生字笔记数据库文件？（如需删除，请使用第三方文件管理器手动删除）")
	            .setPositiveButton("确定", new DialogInterface.OnClickListener() {
					@Override
					public void onClick(DialogInterface dialog, int which) {
						new BackupFavDBTask().execute(CKanjiFavouriteSQLiteOpenHelper.getBackupDataBasePath());
	    			}
	            })
	            .setNegativeButton("取消", new DialogInterface.OnClickListener() {
					@Override
					public void onClick(DialogInterface dialog, int which) {
						
					}
	            })
	            .setOnCancelListener(new OnCancelListener() {
					@Override
					public void onCancel(DialogInterface dialog) {
						
					}
	            })
	            .create();
            
        	case DIALOG_RESUME_FAV_DB:
        		AlertDialog resumeFavDBDialog = new AlertDialog.Builder(this)
		            .setTitle("恢复生字笔记数据库")
		            .setAdapter(resumeFavDBAdapter, new DialogInterface.OnClickListener() {
		                public void onClick(DialogInterface dialog, int which) {
		                	new ResumeFavDBTask().execute(resumeFavDBAdapter.getItem(which));
		                }
		            })
		            .setNegativeButton("取消", new DialogInterface.OnClickListener() {
						@Override
						public void onClick(DialogInterface dialog, int which) {
							
						}
		            })
		            .setOnCancelListener(new OnCancelListener() {
						@Override
						public void onCancel(DialogInterface dialog) {
							
						}
		            })
		            .create();
        		resumeFavDBDialog.setOnShowListener(new OnShowListener() {
        			@Override
					public void onShow(DialogInterface dialog) {
        				resumeFavDBAdapter.clear();
        				String desPath = CKanjiFavouriteSQLiteOpenHelper.getBackupDataBaseParentPath();
        				File desPathFile = new File(desPath);
        				String[] files = desPathFile.list();
        				if (files != null) {
        					for (int i = 0; i < files.length; i++) {
        						resumeFavDBAdapter.add(files[i]);
        					}
        				}
					}
        		});
                return resumeFavDBDialog;
                
            case DIALOG_BACKUP_FAV_CSV:
                return new AlertDialog.Builder(this)
    	            .setTitle("导出生字笔记csv")
    	            .setMessage("是否导出生字笔记csv文件？（如需删除，请使用第三方文件管理器手动删除）")
    	            .setPositiveButton("确定", new DialogInterface.OnClickListener() {
    					@Override
    					public void onClick(DialogInterface dialog, int which) {
    						new BackupFavCSVTask().execute(CKanjiFavouriteSQLiteOpenHelper.getBackupCSVPath());
    	    			}
    	            })
    	            .setNegativeButton("取消", new DialogInterface.OnClickListener() {
    					@Override
    					public void onClick(DialogInterface dialog, int which) {
    						
    					}
    	            })
    	            .setOnCancelListener(new OnCancelListener() {
    					@Override
    					public void onCancel(DialogInterface dialog) {
    						
    					}
    	            })
    	            .create();
                
        	case DIALOG_RESUME_FAV_CSV:
        		AlertDialog resumeFavCSVDialog = new AlertDialog.Builder(this)
		            .setTitle("导入生字笔记csv")
		            .setAdapter(resumeFavCSVAdapter, new DialogInterface.OnClickListener() {
		                public void onClick(DialogInterface dialog, int which) {
		                	new ResumeFavCSVTask().execute(resumeFavCSVAdapter.getItem(which));
		                }
		            })
		            .setNegativeButton("取消", new DialogInterface.OnClickListener() {
						@Override
						public void onClick(DialogInterface dialog, int which) {
							
						}
		            })
		            .setOnCancelListener(new OnCancelListener() {
						@Override
						public void onCancel(DialogInterface dialog) {
							
						}
		            })
		            .create();
        		resumeFavCSVDialog.setOnShowListener(new OnShowListener() {
        			@Override
					public void onShow(DialogInterface dialog) {
        				resumeFavCSVAdapter.clear();
        				String desPath = CKanjiFavouriteSQLiteOpenHelper.getBackupCSVParentPath();
        				File desPathFile = new File(desPath);
        				String[] files = desPathFile.list();
        				if (files != null) {
        					for (int i = 0; i < files.length; i++) {
        						resumeFavCSVAdapter.add(files[i]);
        					}
        				}
					}
        		});
                return resumeFavCSVDialog;
    	}
		return super.onCreateDialog(id);
	}
    
    private void insertHistory(String keyword) {
    	hisDataSrc = new CKanjiHistoryDataSource(this);
    	hisDataSrc.open();
    	historyItems = hisDataSrc.getAllItems();
    	if (historyItems != null) {
    		for (int i = historyItems.size() - 1; i >= 0; i--) {
    			CKanjiHistoryItem item = historyItems.get(i);
    			if (item != null && item.getPlainDesc() != null && item.getPlainDesc().equals(keyword)) {
    				hisDataSrc.deleteItem(item);
    			}
    		}
    	}
    	CKanjiHistoryItem newItem = new CKanjiHistoryItem();
    	newItem.setId(-1);
    	newItem.setPlainDesc(keyword);
    	hisDataSrc.createItem(newItem);
		hisDataSrc.close();
    }
    
    private void updateHistory() {
    	tableViewHistory.clear();
    	hisDataSrc = new CKanjiHistoryDataSource(this);
    	hisDataSrc.open();
    	historyItems = hisDataSrc.getAllItems();
		hisDataSrc.close();
    	if (historyItems != null) {
    		for (int i = historyItems.size() - 1; i >= 0; i--) {
    			CKanjiHistoryItem item = historyItems.get(i);
    			String desc = item.getPlainDesc();
    			Time time = item.getPlainTime();
    			String timeStr = time.format("%Y-%m-%d %H:%M:%S");
    	        tableViewHistory.addBasicItem(desc, timeStr);
    		}
    	}
        tableViewHistory.commit();
    }
    
    private void clearHistory() {
    	tableViewHistory.clear();
        tableViewHistory.commit();
        historyItems = null;
    	hisDataSrc = new CKanjiHistoryDataSource(CKanjiActivity.this);
    	hisDataSrc.open();
    	hisDataSrc.deleteAllItem();
		hisDataSrc.close();
    }

    private void insertFavourite(String word1, String word2) {
    	favDataSrc = new CKanjiFavouriteDataSource(this);
    	favDataSrc.open();
    	favouriteItems = favDataSrc.getAllItems();
    	if (favouriteItems != null) {
    		for (int i = favouriteItems.size() - 1; i >= 0; i--) {
    			CKanjiFavouriteItem item = favouriteItems.get(i);
    			if (item != null 
    				 && 
    				((item.getPlainWord1() == null && word1 == null) || 
    				 (word1 != null && item.getPlainWord1() != null && item.getPlainWord1().equals(word1))
    				 )
    				 &&
    				((item.getPlainWord2() == null && word2 == null) || 
    				 (word2 != null && item.getPlainWord2() != null && item.getPlainWord2().equals(word2))
    				 )
    			   ) {
    				favDataSrc.deleteItem(item);
    			}
    		}
    	}
    	CKanjiFavouriteItem newItem = new CKanjiFavouriteItem();
    	newItem.setId(-1);
    	newItem.setPlainWord1(word1);
    	newItem.setPlainWord2(word2);
    	favDataSrc.createItem(newItem);
		favDataSrc.close();
    }
    
    private void updateFavourite() {
    	tableViewFavourite.clear();
    	favDataSrc = new CKanjiFavouriteDataSource(this);
    	favDataSrc.open();
    	favouriteItems = favDataSrc.getAllItems();
    	if (favouriteItems != null) {
    		for (int i = favouriteItems.size() - 1; i >= 0; i--) {
    			CKanjiFavouriteItem item = favouriteItems.get(i);
    			String word1 = item.getPlainWord1();
    			String word2 = item.getPlainWord2();
    			String memo = item.getPlainMemo();
    			int star = item.getPlainStar();
    			StringBuffer sb = new StringBuffer();
    			if (word1 != null) {
    				sb.append(word1);
    			}
    			sb.append(" / ");
    			if (word2 != null) {
    				sb.append(word2);
    			}
    			Time time = item.getPlainTime();
    			StringBuffer sb2 = new StringBuffer();
    			String timeStr = time.format("%Y-%m-%d %H:%M:%S");
				if (star > 0) {
	    			sb2.append("关注度：");
					sb2.append(Integer.toString(star));
					sb2.append("\n");
				}
				if (memo != null && memo.length() > 0) {
    				sb2.append("备注：");
    				sb2.append(memo);
    				sb2.append("\n");
    				sb2.append("修改时间：");
    				sb2.append(timeStr);
    			} else {
    				sb2.append("修改时间：");
    				sb2.append(timeStr);
    			}
    	        tableViewFavourite.addBasicItem(sb.toString(), sb2.toString());
    		}
    	}
    	favDataSrc.close();
    	tableViewFavourite.commit();
    }
    
    private void shareFavourite() {
    	StringBuffer sbOutput = new StringBuffer();
    	favDataSrc = new CKanjiFavouriteDataSource(this);
    	favDataSrc.open();
    	ArrayList<CKanjiFavouriteItem> favouriteItems = favDataSrc.getAllItems();
    	favDataSrc.close(); 
    	if (favouriteItems != null) {
    		for (int i = favouriteItems.size() - 1; i >= 0; i--) {
    			CKanjiFavouriteItem item = favouriteItems.get(i);
    			String word1 = item.getPlainWord1();
    			String word2 = item.getPlainWord2();
    			String memo = item.getPlainMemo();
    			int star = item.getPlainStar();
    			StringBuffer sb = new StringBuffer();
    			if (word1 != null) {
    				sb.append(word1);
    			}
    			sb.append(" / ");
    			if (word2 != null) {
    				sb.append(word2);
    			}
    			Time time = item.getPlainTime();
    			StringBuffer sb2 = new StringBuffer();
    			String timeStr = time.format("%Y-%m-%d %H:%M:%S");
				if (star > 0) {
	    			sb2.append("关注度：");
					sb2.append(Integer.toString(star));
					sb2.append("\n");
				}
				if (memo != null && memo.length() > 0) {
    				sb2.append("备注：");
    				sb2.append(memo);
    				sb2.append("\n");
    				sb2.append("修改时间：");
    				sb2.append(timeStr);
    			} else {
    				sb2.append("修改时间：");
    				sb2.append(timeStr);
    			}
				sbOutput.append(sb.toString());
				sbOutput.append("\n");
				sbOutput.append(sb2.toString());
				sbOutput.append("\n\n");
    		}
    	}
		Intent intent = new Intent();
		intent.setAction(Intent.ACTION_SEND);
		intent.setType("text/plain");
        intent.putExtra(Intent.EXTRA_SUBJECT, "日语词汇向导生字笔记");
        intent.putExtra(Intent.EXTRA_TEXT, sbOutput.toString());
		try {
			startActivity(intent);
		} catch (Throwable e) {
			e.printStackTrace();
			Toast.makeText(this, 
				"共享方式出错", Toast.LENGTH_SHORT)
				.show();
		}
    }
    
    private void clearFavourite() {
    	tableViewFavourite.clear();
        tableViewFavourite.commit();
        favouriteItems = null;
    	favDataSrc = new CKanjiFavouriteDataSource(CKanjiActivity.this);
    	favDataSrc.open();
    	favDataSrc.deleteAllItem();
    	favDataSrc.close();
    }
    
    /**
     * @see tableViewSettings.setClickListener
     */
	private void updateSettings() {
    	tableViewSettings.clear();
    	tableViewSettings.addBasicItem(new BasicItem("设置", null, false)); // 0
    	tableViewSettings.addBasicItem("匹配类型", getSearchTypeString(getLastSearchType(this))); // 1
    	tableViewSettings.addBasicItem("界面皮肤（更改将重启界面）", getUITypeString(getLastUIType(this))); // 2
    	tableViewSettings.addBasicItem("复制数据库", "重新复制数据库至SD卡"); // 3
    	tableViewSettings.commit();
    }

    /**
     * @see tableViewBackup.setClickListener
     */
	private void updateBackup() {
    	tableViewBackup.clear();
    	tableViewBackup.addBasicItem(new BasicItem("备份与导出", "注意：测试版，请谨慎使用", false)); // 0
    	tableViewBackup.addBasicItem("备份生字笔记数据库", "备份" + CKanjiFavouriteSQLiteOpenHelper.getDataBasePath() + 
    			"至" + CKanjiFavouriteSQLiteOpenHelper.getBackupDataBaseParentPath()); // 1
    	tableViewBackup.addBasicItem("恢复生字笔记数据库", "恢复" + CKanjiFavouriteSQLiteOpenHelper.getBackupDataBaseParentPath() + 
    			"至" + CKanjiFavouriteSQLiteOpenHelper.getDataBasePath() + "\n" + 
    			"注意：恢复将覆盖原数据库内的数据，请先备份"); // 2
    	tableViewBackup.addBasicItem("共享生字笔记", "共享生字笔记到其他应用程序"); // 3
    	tableViewBackup.addBasicItem("导出生字笔记至csv文本", "把生字笔记内容导出至逗号分隔文本文件，用于备份、修改、导入、导入至Excel。"); // 4
    	tableViewBackup.addBasicItem("导入csv文本至生字笔记", "导入逗号分隔文本至生字笔记数据库。\n注意，导入csv将更新已有生字（汉字与假名都相同的词条），添加未有生字"); // 5
    	tableViewBackup.commit();
	}
    
    private void updateAbout() {
    	tableViewAbout.clear();
    	tableViewAbout.addBasicItem(new BasicItem("关于", null, false)); // 4
    	tableViewAbout.addBasicItem(new BasicItem("应用名称", this.getText(R.string.app_name).toString(), false)); // 1
    	tableViewAbout.addBasicItem(new BasicItem("版本号", this.getString(R.string.app_version_name).toString(), false)); // 2
    	tableViewAbout.addBasicItem(new BasicItem("内部版本号", this.getString(R.string.app_version_code).toString(), false)); // 3
    	tableViewAbout.addBasicItem(new BasicItem("作者", this.getString(R.string.app_author).toString(), false)); // 4
    	tableViewAbout.addBasicItem("我的博客", this.getString(R.string.app_blog).toString()); // 5
    	tableViewAbout.addBasicItem("我的邮箱", this.getString(R.string.app_email).toString()); // 6
    	tableViewAbout.commit();
    }
    
    private void updateSearchType() {
    	if (mFlipper.getDisplayedChild() == PAGE_SEARCH) {
    		buttonTitle2.setText(getCurrentSearchType());
    		startSearch(true);
    	}
    	updateSettings();
    }
    
    private void updateUIType() {
    	updateSettings();
    	this.startActivity(
    		new Intent(this, CKanjiActivity.class)
    			.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP)
    	);
    }
    
    private void updateFavType() {
    	if (mFlipper.getDisplayedChild() == PAGE_FAVOURITE) {
    		buttonTitle2.setText(getCurrentFavouriteType());
    		startSearch(true);
    	}
    	updateSettings();
    }
    
    private void updateDetail(int index) {    	
    	this.currentWordItem = index; 
    	tableViewDetail.clear();
    	if (index >= 0 && index < wordItems.size() && index < wordItems.size()) {
    		WordItem item = wordItems.get(index);
    		if (item != null) {
    			tableViewDetail.addBasicItem(new BasicItem(item.word, null/*"汉字"*/, true)); // 0
    			tableViewDetail.addBasicItem(new BasicItem(item.reading, null/*"发音"*/, true)); // 1
    			tableViewDetail.addBasicItem(new BasicItem(item.type, null/*"分类"*/, true)); // 2
    			tableViewDetail.addBasicItem(new BasicItem(item.meaning, null/*"意思"*/, true)); // 3
    			tableViewDetail.addBasicItem(new BasicItem("共享", "共享至其他程序", true)); // 4
    			tableViewDetail.addBasicItem(new BasicItem("收藏", "加入生字笔记", true)); // 5
    		}
    	} else {
			Toast.makeText(this, 
    			"无法获取要共享的字符串", Toast.LENGTH_SHORT)
    			.show();
    	}
    	tableViewDetail.commit();
    	flipPage(PAGE_DETAIL);
    }
    
    private void shareWord(int index) {
    	if (currentWordItem >= 0 && currentWordItem < wordItems.size() && currentWordItem < wordItems.size()) {
    		WordItem item = wordItems.get(currentWordItem);
	    	if (index >= 0 && index <= 3) {
	    		String searchString = "";
	    		switch(index) {
	    		case 0:
	    			searchString = item.word;
	    			break;
	    			
	    		case 1:
	    			searchString = item.reading;
	    			break;
	    			
	    		case 2:
	    			searchString = item.type;
	    			break;
	    			
	    		case 3:
	    			searchString = item.meaning;
	    			break;
	    		}
				ClipboardManager cm = (ClipboardManager) getSystemService(CLIPBOARD_SERVICE);
	            cm.setText(searchString);
	            Toast.makeText(CKanjiActivity.this, "「" + searchString + "」已复制至剪贴板",
	            		Toast.LENGTH_SHORT).show();
	    	} else if (index == 4) {
	    		if (item != null) {	
		    		Intent intent = new Intent();
		    		intent.setAction(Intent.ACTION_SEND);
		    		intent.setType("text/plain");
		            intent.putExtra(Intent.EXTRA_SUBJECT, item.wordStr);
		            intent.putExtra(Intent.EXTRA_TEXT, 
		            	(item.wordStr != null ? 
		            	(item.wordStr + "\n" + item.meanStr) : 
		            	item.meanStr));
		    		try {
		    			startActivity(intent);
		    		} catch (Throwable e) {
		    			e.printStackTrace();
		    			Toast.makeText(this, 
		    				"共享方式出错", Toast.LENGTH_SHORT)
		    				.show();
		    		}
	    		}
	    	} else if (index == 5) {
		    	if (item != null) {
	    			insertFavourite(item.word, item.reading);
	    			updateFavourite();
	    			Toast.makeText(CKanjiActivity.this, 
	    				"添加到生字笔记成功", 
	    				Toast.LENGTH_SHORT).show();
	    		}
			}
    	} else {
			Toast.makeText(this, 
				"无法获取要共享的字符串", Toast.LENGTH_SHORT)
				.show();
		}
    }
    
    private String getCurrentSearchType() {
    	int type = getLastSearchType(this);
    	if (type < 0 || type >= SEARCH_TYPE_ITEMS.length) {
    		return "搜索";
    	} else {
    		return SEARCH_TYPE_ITEMS[type];
    	}
    }
    
    private String getCurrentFavouriteType() {
    	int type = getLastFavType(this);
    	if (type < 0 || type >= FAV_TYPE_ITEMS.length) {
    		return "查看";
    	} else {
    		return FAV_TYPE_ITEMS[type];
    	}    	
    }
    
    private int nextFavouriteType() {
    	switch(getLastFavType(this)) {
    	case FAV_TYPE_VIEW:
    		return FAV_TYPE_EDIT;
    		
    	case FAV_TYPE_EDIT:
    		return FAV_TYPE_VIEW;
    	}
    	return FAV_TYPE_VIEW;
    }
    
    //getLastSearchType()
    private String getSearchTypeString(int type) {
    	switch(type) {
    	case SEARCH_TYPE_PREFIX:
    		return "前缀搜索";
    		
    	case SEARCH_TYPE_INFIX:
    		return "包含搜索";
    		
    	case SEARCH_TYPE_SUFFIX:
    		return "后缀搜索";
    		
    	case SEARCH_TYPE_FULLTEXT:
    		return "全文搜索";
    		
    	case SEARCH_TYPE_FULL:
    		return "精确搜索";
    	}
    	return "";
    }
    
    private int nextSearchType() {
    	switch(getLastSearchType(this)) {
    	case SEARCH_TYPE_PREFIX:
    		return SEARCH_TYPE_INFIX;
    		
    	case SEARCH_TYPE_INFIX:
    		return SEARCH_TYPE_SUFFIX;
    		
    	case SEARCH_TYPE_SUFFIX:
    		return SEARCH_TYPE_FULLTEXT;
    		
    	case SEARCH_TYPE_FULLTEXT:
    		return SEARCH_TYPE_FULL;
    		
    	case SEARCH_TYPE_FULL:
    		return SEARCH_TYPE_PREFIX;
    	}
    	return SEARCH_TYPE_PREFIX;
    }
    
    //getLastUIType()
    private String getUITypeString(int type) {
    	switch(type) {
    	case UI_TYPE_DEFAULT:
    		return UI_TYPE_ITEMS[0];
    		
    	case UI_TYPE_CAT:
    		return UI_TYPE_ITEMS[1];
    	}
    	return "";
    }
    
    private void openBlog() {
    	Intent intent = new Intent();
    	intent.setAction(Intent.ACTION_VIEW);
    	intent.addCategory(Intent.CATEGORY_DEFAULT);
		intent.addCategory(Intent.CATEGORY_BROWSABLE);
		intent.setDataAndType(Uri.parse(getString(R.string.app_blog)), "*/*");
		try {
			this.startActivity(intent);
		} catch (Throwable e) {
			e.printStackTrace();
			Toast.makeText(this, 
				"找不到可用的应用程序", Toast.LENGTH_SHORT)
				.show();
		}	
    }
    
    private void sendEmail() {
		Intent intent = new Intent();
		intent.setAction(Intent.ACTION_SENDTO);
		intent.setData(Uri.parse("mailto:" + getString(R.string.app_email)));
		intent.putExtra(Intent.EXTRA_SUBJECT, "关于 " + getString(R.string.app_name) + " v" + getString(R.string.app_version_name));
		try {
			startActivity(intent);
		} catch (ActivityNotFoundException e) {
			Toast.makeText(this, "找不到发送邮件的应用程序。", Toast.LENGTH_SHORT).show();
			e.printStackTrace();
		}
    }

    public static void setLastSearchType(Context context, int type) {
		Editor e = context.getSharedPreferences(SHARE_PREF_NAME, MODE_PRIVATE).edit();
		e.putInt(SHARE_PREF_SEARCH_TYPE, type);
		e.commit();
    }
    
    public static int getLastSearchType(Context context) {
		SharedPreferences sp = context.getSharedPreferences(SHARE_PREF_NAME, MODE_PRIVATE);
		return sp.getInt(SHARE_PREF_SEARCH_TYPE, SEARCH_TYPE_PREFIX);
    }

    public static void setLastUIType(Context context, int type) {
		Editor e = context.getSharedPreferences(SHARE_PREF_NAME, MODE_PRIVATE).edit();
		e.putInt(SHARE_PREF_UI_TYPE, type);
		e.commit();
    }
    
    public static int getLastUIType(Context context) {
		SharedPreferences sp = context.getSharedPreferences(SHARE_PREF_NAME, MODE_PRIVATE);
		return sp.getInt(SHARE_PREF_UI_TYPE, UI_TYPE_DEFAULT);
    }

    public static void setLastFavType(Context context, int type) {
		Editor e = context.getSharedPreferences(SHARE_PREF_NAME, MODE_PRIVATE).edit();
		e.putInt(SHARE_PREF_FAV_TYPE, type);
		e.commit();
    }
    
    public static int getLastFavType(Context context) {
		SharedPreferences sp = context.getSharedPreferences(SHARE_PREF_NAME, MODE_PRIVATE);
		return sp.getInt(SHARE_PREF_FAV_TYPE, FAV_TYPE_VIEW);
    }
    
    private final class WordItem {
    	String word;
    	String reading;
    	String type;
    	String meaning;
    	String wordStr, meanStr;
    	
    	public WordItem(String _word, String _meaning, String _reading, String _type, String _wordStr, String _meanStr) {
    		this.word = _word;
    		this.reading = _reading;
    		this.type = _type;
    		this.meaning = _meaning;
    		this.wordStr = _wordStr;
    		this.meanStr = _meanStr;
    	}
    };
    
	private class LoadDataTask extends AsyncTask<Void, Void, Boolean> {
		private boolean loadResult = false;
		private String dbname;
		
		@Override
		protected void onPreExecute() {
			super.onPreExecute();
	    	buttonSearch.setEnabled(false);
		}

		@Override
		protected Boolean doInBackground(Void... params) {
			try {
				dbname = DictionaryDatabase.copyDatabase(CKanjiActivity.this); 
				if (dbname != null) {
					loadResult = true;
				} else {
					loadResult = false;
				}
			} catch (Throwable e) {
				e.printStackTrace();
				return false;
			}
			return true;
		}
		
		@Override
		protected void onPostExecute(Boolean result) {
			if (result == true && !CKanjiActivity.this.isFinishing()) {
				if (loadResult) {
					dataBaseFileName = dbname;
					showSearchLoadingSuccess();
				} else {
					dataBaseFileName = null;
					showSearchLoadingFailed();
				}
			} else if (result == false) {
				dataBaseFileName = null;
				finish();
			}
		}
    }
	
	private class BackupFavDBTask extends AsyncTask<String, Void, Boolean> {
		private boolean loadResult = false;
		private String srcPath, desPath;
		@Override
		protected void onPreExecute() {
			super.onPreExecute();
		}
		
		@Override
		protected Boolean doInBackground(String... params) {
			loadResult = false;
			try {
				srcPath = CKanjiFavouriteSQLiteOpenHelper.getDataBasePath();
				desPath = params[0];
				if (srcPath != null) {
					InputStream inputStream = null;
			        BufferedInputStream istr = null; 
			        OutputStream outputStream = null;
			        BufferedOutputStream ostr = null;
			        try {
			        	inputStream = new FileInputStream(srcPath);
			        	istr = new BufferedInputStream(inputStream);
			        	outputStream = new FileOutputStream(desPath);
			        	ostr = new BufferedOutputStream(outputStream);
			        	byte[] bytes = new byte[2048];
			            int size = 0;
			            while (true) {
			                size = istr.read(bytes);
			                if (size >= 0) {
			                	ostr.write(bytes, 0, size);
			                	ostr.flush();
			                } else {
			                	break;
			                }
			            }
			            loadResult = true;
			        } catch (IOException e) {
				        if (D) {
				        	Log.e(TAG, "copying words error!!!");
				        }
			        	e.printStackTrace();
			        } finally {
			        	if (ostr != null) {
			        		try {
			        			ostr.close();
							} catch (IOException e) {
								e.printStackTrace();
							}
			        	}
			        	if (outputStream != null) {
			        		try {
			        			outputStream.close();
							} catch (IOException e) {
								e.printStackTrace();
							}
			        	}
			        	if (istr != null) {
				        	try {
								istr.close();
							} catch (IOException e) {
								e.printStackTrace();
							}
			        	}
			        	if (inputStream != null) {
				        	try {
				        		inputStream.close();
							} catch (IOException e) {
								e.printStackTrace();
							}
			        	}
				        if (D) {
				        	Log.d(TAG, "DONE copying words.");
				        }
			        }
				}
			} catch (Throwable e) {
				e.printStackTrace();
				return false;
			}
			return true;
		}
		
		@Override
		protected void onPostExecute(Boolean result) {
			if (result == true && !CKanjiActivity.this.isFinishing()) {
				if (loadResult) {
					Toast.makeText(CKanjiActivity.this, 
						"备份生字笔记数据库至：\n" + desPath, 
						Toast.LENGTH_SHORT).show();	
				} else {
					Toast.makeText(CKanjiActivity.this, 
						"备份生字笔记数据库失败", 
						Toast.LENGTH_SHORT).show();					
				}
			} else if (result == false) {
				finish();
			}
		}
    }
	
	private class ResumeFavDBTask extends AsyncTask<String, Void, Boolean> {
		private boolean loadResult = false;
		private String srcPath, desPath;
		@Override
		protected void onPreExecute() {
			super.onPreExecute();
		}
		
		@Override
		protected Boolean doInBackground(String... params) {
			loadResult = false;
			try {
				srcPath = CKanjiFavouriteSQLiteOpenHelper.getBackupDataBaseParentPath() + File.separator + params[0];
				desPath = CKanjiFavouriteSQLiteOpenHelper.getDataBasePath();
				if (srcPath != null) {
					InputStream inputStream = null;
			        BufferedInputStream istr = null; 
			        OutputStream outputStream = null;
			        BufferedOutputStream ostr = null;
			        try {
			        	inputStream = new FileInputStream(srcPath);
			        	istr = new BufferedInputStream(inputStream);
			        	outputStream = new FileOutputStream(desPath);
			        	ostr = new BufferedOutputStream(outputStream);
			        	byte[] bytes = new byte[2048];
			            int size = 0;
			            while (true) {
			                size = istr.read(bytes);
			                if (size >= 0) {
			                	ostr.write(bytes, 0, size);
			                	ostr.flush();
			                } else {
			                	break;
			                }
			            }
			            loadResult = true;
			        } catch (IOException e) {
				        if (D) {
				        	Log.e(TAG, "copying words error!!!");
				        }
			        	e.printStackTrace();
			        } finally {
			        	if (ostr != null) {
			        		try {
			        			ostr.close();
							} catch (IOException e) {
								e.printStackTrace();
							}
			        	}
			        	if (outputStream != null) {
			        		try {
			        			outputStream.close();
							} catch (IOException e) {
								e.printStackTrace();
							}
			        	}
			        	if (istr != null) {
				        	try {
								istr.close();
							} catch (IOException e) {
								e.printStackTrace();
							}
			        	}
			        	if (inputStream != null) {
				        	try {
				        		inputStream.close();
							} catch (IOException e) {
								e.printStackTrace();
							}
			        	}
				        if (D) {
				        	Log.d(TAG, "DONE copying words.");
				        }
			        }
				}
			} catch (Throwable e) {
				e.printStackTrace();
				return false;
			}
			return true;
		}
		
		@Override
		protected void onPostExecute(Boolean result) {
			if (result == true && !CKanjiActivity.this.isFinishing()) {
				if (loadResult) {
					updateFavourite();
					Toast.makeText(CKanjiActivity.this, 
						"恢复生字笔记数据库成功", 
						Toast.LENGTH_SHORT).show();
				} else {
					Toast.makeText(CKanjiActivity.this, 
						"恢复生字笔记数据库失败", 
						Toast.LENGTH_SHORT).show();					
				}
			} else if (result == false) {
				finish();
			}
		}
    }
	
	private class BackupFavCSVTask extends AsyncTask<String, Void, Boolean> {
		private boolean loadResult = false;
		private ArrayList<CKanjiFavouriteItem> items;
		private String desPath;
		
		@Override
		protected void onPreExecute() {
			super.onPreExecute();
	    	favDataSrc = new CKanjiFavouriteDataSource(CKanjiActivity.this);
	    	favDataSrc.open();
	    	items = favDataSrc.getAllItems();
	    	favDataSrc.close(); 
		}
		
		@Override
		protected Boolean doInBackground(String... params) {
			loadResult = false;
			try {
		        FileOutputStream ostr = null;
		        OutputStreamWriter writer = null;
		        BufferedWriter obuf = null;
		        CsvWriter csvOutput = null;
		        desPath = params[0];
		        try {
		    		ostr = new FileOutputStream(desPath);
		    		writer = new OutputStreamWriter(ostr, "UTF-8");
		    		obuf = new BufferedWriter(writer);
		    		csvOutput = new CsvWriter(obuf, ',');
		            csvOutput.write("word1");
		            csvOutput.write("word2");
		            csvOutput.write("memo");
		            csvOutput.write("star");
		            csvOutput.endRecord();
		            if (items != null) {
		        		for (int i = 0; i < items.size(); i++) {
		        			CKanjiFavouriteItem item = items.get(i);
				            csvOutput.write(item.getPlainWord1());
				            csvOutput.write(item.getPlainWord2());
				            csvOutput.write(item.getPlainMemo());
				            csvOutput.write(Integer.toString(item.getPlainStar()));
				            csvOutput.endRecord();
		        		}
		        	}
		            loadResult = true;
		        } catch (IOException e) {
		            e.printStackTrace();
		        } finally {
		        	if (csvOutput != null) {
		        		csvOutput.close();
		        	}
		        	if (obuf != null) {
		        		try {
							obuf.close();
						} catch (IOException e) {
							e.printStackTrace();
						}
		        	}
		        	if (writer != null) {
		        		try {
							writer.close();
						} catch (IOException e) {
							e.printStackTrace();
						}
		        	}
		        	if (ostr != null) {
		        		try {
							ostr.close();
						} catch (IOException e) {
							e.printStackTrace();
						}
		        	}
		        }
			} catch (Throwable e) {
				e.printStackTrace();
				return false;
			}
			return true;
		}
		
		@Override
		protected void onPostExecute(Boolean result) {
			if (result == true && !CKanjiActivity.this.isFinishing()) {
				if (loadResult) {
					Toast.makeText(CKanjiActivity.this, 
						"导出生字笔记csv至：\n" + desPath, 
						Toast.LENGTH_SHORT).show();
				} else {
					Toast.makeText(CKanjiActivity.this, 
						"导出生字笔记csv失败", 
						Toast.LENGTH_SHORT).show();					
				}
			} else if (result == false) {
				finish();
			}
		}
    }
	
	
	private class ResumeFavCSVTask extends AsyncTask<String, Void, Boolean> {
		private boolean loadResult = false;
		private ArrayList<CKanjiFavouriteItem> items;
		private ArrayList<CKanjiFavouriteItem> oriItems;
		private String srcPath;
		
		@Override
		protected void onPreExecute() {
			super.onPreExecute();
			items = new ArrayList<CKanjiFavouriteItem>();
			favDataSrc = new CKanjiFavouriteDataSource(CKanjiActivity.this);
	    	favDataSrc.open();
	    	oriItems = favDataSrc.getAllItems();
	    	favDataSrc.close();
		}
		
		@Override
		protected Boolean doInBackground(String... params) {
			loadResult = false;
			try {
				srcPath = CKanjiFavouriteSQLiteOpenHelper.getBackupCSVParentPath() + File.separator + params[0];
				FileInputStream istr = null;
		        InputStreamReader reader = null;
		        BufferedReader ibuf = null;
		        CsvReader csvInput = null;
		        try {
		    		istr = new FileInputStream(srcPath);
		    		reader = new InputStreamReader(istr, "UTF-8");
		    		ibuf = new BufferedReader(reader);
		    		csvInput = new CsvReader(ibuf);
		    		csvInput.readHeaders();
		            while (csvInput.readRecord()) {
		            	CKanjiFavouriteItem item = new CKanjiFavouriteItem();
		            	item.setId(-1L);
		            	String word1 = csvInput.get("word1");
		            	String word2 = csvInput.get("word2");
		            	item.setPlainWord1(word1);
		            	item.setPlainWord2(word2);
		            	item.setPlainMemo(csvInput.get("memo"));
		            	String strStar = csvInput.get("star");
		            	int star = 0;
		            	try {
		            		star = Integer.parseInt(strStar);
		            	} catch (Throwable e) {
		            		e.printStackTrace();
		            	}
		            	item.setPlainStar(star);
		            	if (word1 == null) {
		            		word1 = "";
		            	}
		            	if (word2 == null) {
		            		word2 = "";
		            	}
			    		for (int j = 0; j < oriItems.size(); j++) {
			    			CKanjiFavouriteItem oriItem = oriItems.get(j);
			    			String oriWord1 = oriItem.getPlainWord1();
			    			String oriWord2 = oriItem.getPlainWord2();
			    			if (oriWord1 == null) {
			    				oriWord1 = "";
			            	}
			            	if (oriWord2 == null) {
			            		oriWord2 = "";
			            	}
			    			if (word1.equals(oriWord1) && word2.equals(oriWord2)) {
			    				item.setId(oriItem.getId());
			    				break;
			    			}
			    		}
		            	items.add(item);
		            }
		            loadResult = true;
		        } catch (IOException e) {
		            e.printStackTrace();
		        } finally {
		        	if (csvInput != null) {
		        		csvInput.close();
		        	}
		        	if (ibuf != null) {
		        		try {
							ibuf.close();
						} catch (IOException e) {
							e.printStackTrace();
						}
		        	}
		        	if (reader != null) {
		        		try {
		        			reader.close();
						} catch (IOException e) {
							e.printStackTrace();
						}
		        	}
		        	if (istr != null) {
		        		try {
							istr.close();
						} catch (IOException e) {
							e.printStackTrace();
						}
		        	}
		        }
			} catch (Throwable e) {
				e.printStackTrace();
				return false;
			}
			return true;
		}
		
		@Override
		protected void onPostExecute(Boolean result) {
			if (result == true && !CKanjiActivity.this.isFinishing()) {
				if (loadResult) {
					favDataSrc = new CKanjiFavouriteDataSource(CKanjiActivity.this);
			    	favDataSrc.open();
			    	for (int i = 0; i < items.size(); i++) {
			    		CKanjiFavouriteItem item = items.get(i);
			    		favDataSrc.createItem(item);
			    	}
			    	favDataSrc.close();
					updateFavourite();
					Toast.makeText(CKanjiActivity.this, 
						"导入生字笔记csv成功", 
						Toast.LENGTH_SHORT).show();
				} else {
					Toast.makeText(CKanjiActivity.this, 
						"导入生字笔记csv失败", 
						Toast.LENGTH_SHORT).show();					
				}
			} else if (result == false) {
				finish();
			}
		}
    }
	
	
	
	
	
	
	
	private class SearchTask extends AsyncTask<String, Void, Boolean> {
		private boolean loadResult = false;
		private int resultNum = 0;
		private String keyword = "";
		private int type = SEARCH_TYPE_PREFIX;
		
		@Override
		protected void onPreExecute() {
			super.onPreExecute();
			buttonSearch.setEnabled(false);
			tableViewSearch.clear();
			wordItems.clear();
			showSearchStart();
		}

		@Override
		protected Boolean doInBackground(String... params) {
			if (params[0] != null) {
				keyword = params[0];
			} else {
				keyword = "";
			}
			try {
				type = Integer.parseInt(params[1]);
			} catch (Throwable e) {
				e.printStackTrace();
			}
			try {
				SQLiteDatabase db = null;
				boolean result = true;
				String dbPath = dataBaseFileName;
				try {
					db = SQLiteDatabase.openDatabase(dbPath, 
						null, 
						SQLiteDatabase.OPEN_READONLY | SQLiteDatabase.NO_LOCALIZED_COLLATORS);
					Cursor cursor = null;
					String selection = null;
					String[] selectionArgs = null;
					String[] columns = null;
					switch(type) {
					case SEARCH_TYPE_PREFIX:
						selection = DictionaryOpenHelper.KEY_WORD + " LIKE ?" + " OR " + 
								DictionaryOpenHelper.KEY_WORD2 + " LIKE ?" + " OR " +
								DictionaryOpenHelper.KEY_READING + " LIKE ?";
						selectionArgs = new String[]{keyword + "%", keyword + "%", keyword + "%"};
						break;
						
					case SEARCH_TYPE_INFIX:
						selection = DictionaryOpenHelper.KEY_WORD + " LIKE ?" + " OR " + 
								DictionaryOpenHelper.KEY_WORD2 + " LIKE ?" + " OR " +
								DictionaryOpenHelper.KEY_READING + " LIKE ?";
						selectionArgs = new String[]{"%" + keyword + "%", "%" + keyword + "%", "%" + keyword + "%"};
						break;
					
					case SEARCH_TYPE_SUFFIX:
						selection = DictionaryOpenHelper.KEY_WORD + " LIKE ?" + " OR " +
								DictionaryOpenHelper.KEY_WORD2 + " LIKE ?" + " OR " +
								DictionaryOpenHelper.KEY_READING + " LIKE ?";
						selectionArgs = new String[]{"%" + keyword, "%" + keyword, "%" + keyword};
						break;
						
					case SEARCH_TYPE_FULLTEXT:
						selection = DictionaryOpenHelper.KEY_WORD + " LIKE ?" + " OR " +
								DictionaryOpenHelper.KEY_WORD2 + " LIKE ?" + " OR " +
								DictionaryOpenHelper.KEY_READING + " LIKE ?" + " OR " +
								DictionaryOpenHelper.KEY_DEFINITION + " LIKE ?";
						selectionArgs = new String[]{"%" + keyword + "%", "%" + keyword + "%", "%" + keyword + "%", "%" + keyword + "%"};
						break;
						
					case SEARCH_TYPE_FULL:
						selection = DictionaryOpenHelper.KEY_WORD + " LIKE ?" + " OR " +
								DictionaryOpenHelper.KEY_WORD2 + " LIKE ?" + " OR " +
								DictionaryOpenHelper.KEY_READING + " LIKE ?";
						selectionArgs = new String[]{keyword, keyword, keyword};
						break;
					}
					columns = new String[]{
						DictionaryOpenHelper.KEY_WORD, 
						DictionaryOpenHelper.KEY_DEFINITION,
						DictionaryOpenHelper.KEY_READING,
						DictionaryOpenHelper.KEY_TYPE,
					};
					cursor = db.query(false, //destinct
							DictionaryOpenHelper.FTS_VIRTUAL_TABLE, //table
							columns, //columns
							selection, //"word LIKE ?", //selection
							selectionArgs, //new String[]{"%明日%"}, //selectionArgs
							null, //groupBy
							null, //having
							DictionaryOpenHelper.KEY_READING + " ASC", //orderBy
							null); //"0, 10"); //limit
					try {
						resultNum = 0;
						while (cursor.moveToNext()) {
							String word = cursor.getString(0);
							String meaning = cursor.getString(1);
							String reading = cursor.getString(2);
							String type = cursor.getString(3);
							String wordStr = "";
							if (word != null && word.length() > 0) {
								wordStr += word;
							}
							if (wordStr.length() > 0) {
								if (reading != null && reading.length() > 0) {
									wordStr += "【" + reading + "】";
								}
							} else {
								if (reading != null && reading.length() > 0) {
									wordStr = reading;
								}
							}
							String meanStr = "";
							if (type != null && type.length() > 0) {
								meanStr +=  "【" + type + "】\n";
							}
							if (meaning != null && meaning.length() > 0) {
								meanStr += meaning;
							}
							wordItems.add(new WordItem(word, meaning, reading, type, wordStr, meanStr));
							tableViewSearch.addBasicItem(wordStr, meanStr);
							resultNum++;
						}
					} catch (Throwable e) {
						e.printStackTrace();
						result = false;
					} finally {
						if (cursor != null) {
							cursor.close();
						}
					}
				} catch (Throwable e) {
					e.printStackTrace();
					result = false;
				} finally {
					if (db != null) {
						db.close();
					} 
				}
				loadResult = result;
			} catch (Throwable e) {
				e.printStackTrace();
				return false;
			}
			return true;
		}
		
		@Override
		protected void onPostExecute(Boolean result) {
			if (result == true && !CKanjiActivity.this.isFinishing()) {
				tableViewSearch.commit();
				buttonSearch.setEnabled(true);
				tableViewSearch.requestFocus();
				tableViewSearch.requestFocusFromTouch();
				if (loadResult) {
					showSearchEnd(keyword, type, resultNum);
					if (resultNum > 0) {
						InputMethodManager inputMethodManager = (InputMethodManager) getSystemService(Context.INPUT_METHOD_SERVICE);
						inputMethodManager.hideSoftInputFromWindow(editTextInput.getWindowToken(), 0);
					}
				} else {
					wordItems.clear();
					showSearchFailed(type);
				}
			} else if (result == false) {
				wordItems.clear();
				dataBaseFileName = null;
				finish();
			}
			searchTask = null;
			tableViewSearch.invalidate();
		}
    }
}

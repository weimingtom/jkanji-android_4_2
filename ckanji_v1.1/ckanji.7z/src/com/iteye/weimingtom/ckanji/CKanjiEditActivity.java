package com.iteye.weimingtom.ckanji;

import java.util.ArrayList;

import android.app.Activity;
import android.app.AlertDialog;
import android.app.Dialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.DialogInterface.OnCancelListener;
import android.os.Bundle;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.CompoundButton;
import android.widget.CompoundButton.OnCheckedChangeListener;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.RelativeLayout;
import android.widget.TextView;
import android.widget.Toast;

public class CKanjiEditActivity extends Activity {
	public final static String EXTRA_FAV_ID = "CKanjiEditActivity.EXTRA_FAV_ID";
	
	private final static int DIALOG_DELETE_FAVOURITE = 1;
	
	private Button buttonTitle1, buttonTitle2;
	private TextView textViewTitle;
	
	private LinearLayout linearLayoutTop;
	private RelativeLayout titleBar;
	
	private EditText editTextWord1, editTextWord2, editTextMemo, editTextStar;
	private Button buttonPrev, buttonNext;
	private Button buttonCommit, buttonDelete, buttonCancel, buttonSearch;
	private CheckBox checkBoxHideWord1, checkBoxHideWord2;
	
	private TextView textViewInfo;

	private long favId = -1L;
	private long curId = -1L;
	
	private ArrayList<CKanjiFavouriteItem> favItems;
	
	private final class SaveData {
		long curId;
	}
	
    /** Called when the activity is first created. */
    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.edit);
        
        buttonTitle1 = (Button) findViewById(R.id.buttonTitle1);
        buttonTitle2 = (Button) findViewById(R.id.buttonTitle2);
        textViewTitle = (TextView) findViewById(R.id.textViewTitle);
        
        linearLayoutTop = (LinearLayout) findViewById(R.id.linearLayoutTop);
        titleBar = (RelativeLayout) findViewById(R.id.titleBar);
        
        editTextWord1 = (EditText) findViewById(R.id.editTextWord1);
        editTextWord2 = (EditText) findViewById(R.id.editTextWord2);
        editTextMemo = (EditText) findViewById(R.id.editTextMemo);
        editTextStar = (EditText) findViewById(R.id.editTextStar);
        
        checkBoxHideWord1 = (CheckBox) findViewById(R.id.checkBoxHideWord1);
        checkBoxHideWord2 = (CheckBox) findViewById(R.id.checkBoxHideWord2);
        buttonPrev = (Button) findViewById(R.id.buttonPrev);
        buttonNext = (Button) findViewById(R.id.buttonNext);
        
        buttonCommit = (Button) findViewById(R.id.buttonCommit);
        buttonDelete = (Button) findViewById(R.id.buttonDelete);
        buttonCancel = (Button) findViewById(R.id.buttonCancel);
        buttonSearch = (Button) findViewById(R.id.buttonSearch);
        
        textViewInfo = (TextView) findViewById(R.id.textViewInfo);
        
        buttonTitle1.setText("上一条");
        buttonTitle2.setText("下一条");
        textViewTitle.setText("生字笔记编辑");
        
    	if (CKanjiActivity.getLastUIType(this) == CKanjiActivity.UI_TYPE_CAT) {
    		linearLayoutTop.setBackgroundResource(R.drawable.bgpattern);
    		titleBar.setBackgroundResource(R.drawable.bar_top2);
    	} else {
    		linearLayoutTop.setBackgroundColor(0xffd3d3d3);
    		titleBar.setBackgroundResource(R.drawable.bar_top);
    	}
    	
    	buttonTitle1.setOnClickListener(new OnClickListener() {
			@Override
			public void onClick(View v) {
				nextRecord(false);
			}
    	});
    	buttonTitle2.setOnClickListener(new OnClickListener() {
			@Override
			public void onClick(View v) {
				nextRecord(true);
			}
    	});
    	buttonPrev.setOnClickListener(new OnClickListener() {
			@Override
			public void onClick(View v) {
				nextRecord(false);
			}
    	});
    	buttonNext.setOnClickListener(new OnClickListener() {
			@Override
			public void onClick(View v) {
				nextRecord(true);
			}
    	});
    	checkBoxHideWord1.setOnCheckedChangeListener(new OnCheckedChangeListener() {
			@Override
			public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
				if (isChecked) {
					editTextWord1.setVisibility(EditText.INVISIBLE);
				} else {
					editTextWord1.setVisibility(EditText.VISIBLE);
				}
			}
    	});
    	checkBoxHideWord2.setOnCheckedChangeListener(new OnCheckedChangeListener() {
			@Override
			public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
				if (isChecked) {
					editTextWord2.setVisibility(EditText.INVISIBLE);
				} else {
					editTextWord2.setVisibility(EditText.VISIBLE);
				}				
			}
    	});
    	buttonCommit.setOnClickListener(new OnClickListener() {
			@Override
			public void onClick(View v) {
				commitFav();
				finish();
			}
    	});
    	buttonDelete.setOnClickListener(new OnClickListener() {
			@Override
			public void onClick(View v) {
				showDialog(DIALOG_DELETE_FAVOURITE);
			}
    	});
    	buttonCancel.setOnClickListener(new OnClickListener() {
			@Override
			public void onClick(View v) {
				finish();
			}
    	});
    	buttonSearch.setOnClickListener(new OnClickListener() {
			@Override
			public void onClick(View v) {
				String word1 = editTextWord1.getText().toString();
				String word2 = editTextWord2.getText().toString();
				String keyword = null;
				if (word1 != null && word1.length() > 0) {
					keyword = word1;
				} else if (word2 != null && word2.length() > 0){
					keyword = word2;
				} 
				if (keyword != null && keyword.length() > 0) {
					startActivity(new Intent(CKanjiEditActivity.this,
						CKanjiActivity.class)
						.putExtra(CKanjiActivity.EXTRA_KEYWORD, keyword)
					);	
				} else {
					Toast.makeText(CKanjiEditActivity.this, 
						"关键词为空", 
						Toast.LENGTH_SHORT).show();
				}
			}
    	});

    	SaveData saveData = (SaveData) this.getLastNonConfigurationInstance();
    	if (saveData != null) {
    		this.curId = saveData.curId;
    	} else {
    		this.curId = -1L;
    	}
    	
    	Intent intent = this.getIntent();
    	if (intent != null) {
    		this.favId = intent.getLongExtra(EXTRA_FAV_ID, -1L);
    		if (this.curId == -1L) {
    			this.curId = this.favId;
    		}
    		CKanjiFavouriteDataSource dataSrc = new CKanjiFavouriteDataSource(this);
    		dataSrc.open();
    		CKanjiFavouriteItem item = dataSrc.getItemById(this.curId);
    		if (item != null) {
    			String word1 = item.getPlainWord1();
    			String word2 = item.getPlainWord2();
    			String memo = item.getPlainMemo();
    			int star = item.getPlainStar();
    			editTextWord1.setText("");
    			if (word1 != null) {
    				editTextWord1.append(word1);
    			}
    			editTextWord2.setText("");
    			if (word2 != null) {
    				editTextWord2.append(word2);
    			}
    			editTextMemo.setText("");
    			if (memo != null) {
    				editTextMemo.append(memo);
    			}
    			editTextStar.setText("");
    			editTextStar.append(Integer.toString(star));
    		}
    		dataSrc.close();
    	}
    }
    
    private void commitFav() {
    	if (this.curId >= 0) {
			String word1 = editTextWord1.getText().toString();
			String word2 = editTextWord2.getText().toString();
			String memo = editTextMemo.getText().toString();
			int star = 0;
			try {
				star = Integer.parseInt(editTextStar.getText().toString());
			} catch (Throwable e) {
				e.printStackTrace();
			}
			CKanjiFavouriteDataSource dataSrc = new CKanjiFavouriteDataSource(this);
			dataSrc.open();
			CKanjiFavouriteItem item = new CKanjiFavouriteItem();
			item.setId(this.curId);
			item.setPlainWord1(word1);
			item.setPlainWord2(word2);
			item.setPlainMemo(memo);
			item.setPlainStar(star);
			dataSrc.createItem(item);
			dataSrc.close();
	    }
    }
    
    private void deleteFav() {
    	if (this.curId >= 0L) {
			CKanjiFavouriteDataSource dataSrc = new CKanjiFavouriteDataSource(this);
			dataSrc.open();
			CKanjiFavouriteItem item = new CKanjiFavouriteItem();
			item.setId(this.curId);
			dataSrc.deleteItem(item);
			dataSrc.close();
	    }
    }
    
	@Override
	protected Dialog onCreateDialog(int id) {
    	switch (id) {
        case DIALOG_DELETE_FAVOURITE:
            return new AlertDialog.Builder(this)
            .setTitle("删除生字笔记")
            .setMessage("是否真的删除当前生字笔记？")
            .setPositiveButton("确定", new DialogInterface.OnClickListener() {
				@Override
				public void onClick(DialogInterface dialog, int which) {
					deleteFav();
					finish();
				}
            })
            .setNegativeButton("取消", new DialogInterface.OnClickListener() {
				@Override
				public void onClick(DialogInterface dialog, int which) {
					
				}
            })
            .setOnCancelListener(new OnCancelListener() {
				@Override
				public void onCancel(DialogInterface dialog) {
					
				}
            })
            .create();
    	}
		return super.onCreateDialog(id);
	}

	@Override
	public Object onRetainNonConfigurationInstance() {
		SaveData saveData = new SaveData();
		saveData.curId = this.curId;
		return saveData;
	}
	
	private void nextRecord(boolean isNext) {
		textViewInfo.setVisibility(TextView.INVISIBLE);
    	if (this.curId >= 0L) {
			if (favItems == null) {
				CKanjiFavouriteDataSource dataSrc = new CKanjiFavouriteDataSource(this);
				dataSrc.open();
				favItems = dataSrc.getAllItems();
				dataSrc.close();
			}
			if (favItems != null && favItems.size() > 0) {
				boolean isFound = false;
				int index;
				for (index = 0; index < favItems.size(); index++) {
					CKanjiFavouriteItem item = favItems.get(index);
					if (item != null && item.getId() == this.curId) {
						isFound = true;
						break;
					}
				}
				if (isFound == true) {
					if (isNext) {
						index++;
						if (index > favItems.size() - 1) {
							index = favItems.size() - 1;
						}
					} else {
						index--;
						if (index < 0) {
							index = 0;
						}
					}
					if (index >= 0 && index < favItems.size()) {
						CKanjiFavouriteItem item = favItems.get(index);
						if (item != null) {
							this.curId = item.getId();
			    			String word1 = item.getPlainWord1();
			    			String word2 = item.getPlainWord2();
			    			String memo = item.getPlainMemo();
			    			int star = item.getPlainStar();
			    			editTextWord1.setText("");
			    			if (word1 != null) {
			    				editTextWord1.append(word1);
			    			}
			    			editTextWord2.setText("");
			    			if (word2 != null) {
			    				editTextWord2.append(word2);
			    			}
			    			editTextMemo.setText("");
			    			if (memo != null) {
			    				editTextMemo.append(memo);
			    			}
			    			editTextStar.setText("");
			    			editTextStar.append(Integer.toString(star));
						}
						if (index == 0 || index == favItems.size() - 1) {
							if (isNext) {
								textViewInfo.setVisibility(TextView.VISIBLE);
								textViewInfo.setText("已经是最后一条。");
							} else {
								textViewInfo.setVisibility(TextView.VISIBLE);
								textViewInfo.setText("已经是第一条。");
							}
						}
					}
				}
			}
	    }
	}
}

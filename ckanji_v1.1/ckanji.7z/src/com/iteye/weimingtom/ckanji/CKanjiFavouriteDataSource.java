package com.iteye.weimingtom.ckanji;

import java.util.ArrayList;
import java.util.List;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.SQLException;
import android.database.sqlite.SQLiteDatabase;
import android.text.format.Time;
import android.util.Log;

public class CKanjiFavouriteDataSource {
	private final static boolean D = false;
	private final static String TAG = "CKanjiFavouriteDataSource";
	
	private SQLiteDatabase database;
	private CKanjiFavouriteSQLiteOpenHelper dbHelper;

	private final String[] allColumns = { 
		CKanjiFavouriteSQLiteOpenHelper.COLUMN_ID,
		CKanjiFavouriteSQLiteOpenHelper.COLUMN_CONTENT, 
	};

	public CKanjiFavouriteDataSource(Context context) {
		dbHelper = new CKanjiFavouriteSQLiteOpenHelper(context);
	}
	
	public void open() throws SQLException {
		database = dbHelper.getWritableDatabase();
	}
	
	public void close() {
		if (database != null) {
			database.close();
			database = null;
		}
		if (dbHelper != null) {
			dbHelper.close();
			dbHelper = null;
		}
	}

	public long createItem(CKanjiFavouriteItem item) {
		Time currTime = new Time(Time.getCurrentTimezone());
		currTime.setToNow();
		item.setPlainTime(currTime);
		ContentValues values = new ContentValues();
		long insertId;
		values.put(CKanjiFavouriteSQLiteOpenHelper.COLUMN_CONTENT, item.getContent());
		if (item.getId() < 0) {
			insertId = database.insert(CKanjiFavouriteSQLiteOpenHelper.TABLE_FAVOURITE, 
				null, values);
			if (D) {
				Log.d(TAG, "insert(" + item.getId() + "," + insertId + ") " + item);
			}
			return insertId;
		} else {
			insertId = item.getId();
			database.update(CKanjiFavouriteSQLiteOpenHelper.TABLE_FAVOURITE,
				values, 
				CKanjiFavouriteSQLiteOpenHelper.COLUMN_ID + " = " + insertId, 
				null);
			if (D) {
				Log.d(TAG, "update(" + item.getId() + "," + insertId + ") " + item);
			}
			return insertId;
		}
	}

	private CKanjiFavouriteItem cursorToItem(Cursor cursor) {
		CKanjiFavouriteItem content = new CKanjiFavouriteItem();
		content.setId(cursor.getLong(0));
		content.setContent(cursor.getString(1));
		return content;
	}

	public void deleteItem(CKanjiFavouriteItem content) {
		long id = content.getId();
		database.delete(CKanjiFavouriteSQLiteOpenHelper.TABLE_FAVOURITE, 
			CKanjiFavouriteSQLiteOpenHelper.COLUMN_ID + " = " + id, null);
	}

	public void deleteAllItem() {
		database.delete(CKanjiFavouriteSQLiteOpenHelper.TABLE_FAVOURITE, 
			null, null);
	}
	
	public ArrayList<CKanjiFavouriteItem> getAllItems() {
		ArrayList<CKanjiFavouriteItem> contents = new ArrayList<CKanjiFavouriteItem>();
		Cursor cursor = database.query(CKanjiFavouriteSQLiteOpenHelper.TABLE_FAVOURITE,
				allColumns, 
				null, null, 
				null, null, 
				CKanjiFavouriteSQLiteOpenHelper.COLUMN_ID + " ASC");
		cursor.moveToFirst();
		while (!cursor.isAfterLast()) {
			CKanjiFavouriteItem content = cursorToItem(cursor);
			contents.add(content);
			cursor.moveToNext();
		}
		cursor.close();
		return contents;
	}
	
	public CKanjiFavouriteItem getItemById(long id) {
		CKanjiFavouriteItem item = null;
		Cursor cursor = database.query(CKanjiFavouriteSQLiteOpenHelper.TABLE_FAVOURITE,
				allColumns, 
				CKanjiFavouriteSQLiteOpenHelper.COLUMN_ID + " = " + id, null, 
				null, null, null);
		cursor.moveToFirst();
		while (!cursor.isAfterLast()) {
			item = cursorToItem(cursor);
			cursor.moveToNext();
		}
		return item;
	}
}

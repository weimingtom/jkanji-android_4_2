package com.iteye.weimingtom.ckanji;

import org.json.JSONException;
import org.json.JSONObject;

import android.text.format.Time;
import android.util.Log;

public class CKanjiFavouriteItem {
	private final static boolean D = false;
	private final static String TAG = "CKanjiFavouriteItem";
	
	private long id = -1L;
	private String content;

	private String plainWord1;
	private String plainWord2;
	private String plainMemo;
	private int plainStar;
	private Time plainTime;

	public long getId() {
		return id;
	}

	public void setId(long id) {
		this.id = id;
	}
	
	@Override
	public String toString() {
		return getContent();
	}
	
	public String getContent() {
		JSONObject jsonObject = new JSONObject();
		try {
			jsonObject.put("plainWord1", plainWord1);
			jsonObject.put("plainWord2", plainWord2);
			jsonObject.put("plainMemo", plainMemo);
			jsonObject.put("plainStar", plainStar);
			if (plainTime == null) {
				plainTime = new Time();
			}
			jsonObject.put("plainTime", plainTime.format2445());
		} catch (JSONException e) {
			e.printStackTrace();
		}
		content = jsonObject.toString();
		return content;
	}
	
	/**
	 * @see http://blog.csdn.net/jj120522/article/details/7710859
	 * @param content
	 */
	public void setContent(String content) {
		this.content = content;
		try {
			JSONObject jsonObject = new JSONObject(content);
			plainWord1 = jsonObject.optString("plainWord1");
			plainWord2 = jsonObject.optString("plainWord2");
			plainMemo = jsonObject.optString("plainMemo");
			plainStar = jsonObject.optInt("plainStar", 0);
			String strPlainTime = jsonObject.optString("plainTime");
			plainTime = new Time();
			try {
				plainTime.parse(strPlainTime);
			} catch (Throwable e) {
				e.printStackTrace();
			}
		} catch (JSONException e) {
			e.printStackTrace();
		}
	}

	public String getPlainWord1() {
		return plainWord1;
	}

	public void setPlainWord1(String plainWord1) {
		this.plainWord1 = plainWord1;
	}

	public String getPlainWord2() {
		return plainWord2;
	}

	public void setPlainWord2(String plainWord2) {
		this.plainWord2 = plainWord2;
	}

	public String getPlainMemo() {
		return plainMemo;
	}

	public void setPlainMemo(String plainMemo) {
		this.plainMemo = plainMemo;
	}
	
	public int getPlainStar() {
		return plainStar;
	}

	public void setPlainStar(int plainStar) {
		this.plainStar = plainStar;
	}
	
	public Time getPlainTime() {
		return plainTime;
	}

	public void setPlainTime(Time plainTime) {
		this.plainTime = plainTime;
	}
	
	
}

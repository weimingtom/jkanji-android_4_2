package com.iteye.weimingtom.ckanji;

import java.io.File;

import android.content.Context;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.os.Environment;
import android.text.format.Time;

public class CKanjiFavouriteSQLiteOpenHelper extends SQLiteOpenHelper {
	private final static boolean D = false;
	private final static String TAG = "CKanjiFavouriteSQLiteOpenHelper";
	
	public static final String TABLE_FAVOURITE = "favourite";
	public static final String COLUMN_ID = "_id";
	public static final String COLUMN_CONTENT = "content";

	private static final String DATABASE_NAME = "favourite_data.db";
	private static final int DATABASE_VERSION = 1;

	private static final String DATABASE_CREATE = 
			"create table " + TABLE_FAVOURITE + 
			"( " + 
			COLUMN_ID + " integer primary key autoincrement, " + 
			COLUMN_CONTENT + " text not null " + 
			");";

	public CKanjiFavouriteSQLiteOpenHelper(final Context context) {
		super(context, createExternalDatabase(context), null, DATABASE_VERSION);
	}

	@Override
	public void onCreate(final SQLiteDatabase db) {
		db.execSQL(DATABASE_CREATE);
	}

	@Override
	public void onUpgrade(final SQLiteDatabase db, final int oldVersion, final int newVersion) {
		db.execSQL("DROP TABLE IF EXISTS " + TABLE_FAVOURITE);
		onCreate(db);
	}
	
	public static String getDataBasePath() {
        File path = new File(Environment.getExternalStorageDirectory() +
            	"/ckanji/db/");
        File file = new File(path, DATABASE_NAME);
        return file.getAbsolutePath();    
	}

	public static String getBackupDataBaseParentPath() {
        File path = new File(Environment.getExternalStorageDirectory() +
            	"/ckanji/fav_db/");
        return path.getAbsolutePath();
	}
	
	public static String getBackupDataBasePath() {
        File path = new File(Environment.getExternalStorageDirectory() +
            	"/ckanji/fav_db/");
        Time time = new Time();
        time.setToNow();
        String timeStr = time.format("%Y%m%d%H%M%S");
        File file = new File(path, DATABASE_NAME + "." + timeStr);
        return file.getAbsolutePath();
	}
	
	public static String getBackupCSVParentPath() {
        File path = new File(Environment.getExternalStorageDirectory() +
            	"/ckanji/fav_csv/");
        return path.getAbsolutePath();
	}
	
	public static String getBackupCSVPath() {
        File path = new File(Environment.getExternalStorageDirectory() +
            	"/ckanji/fav_csv/");
        Time time = new Time();
        time.setToNow();
        String timeStr = time.format("%Y%m%d%H%M%S");
        File file = new File(path, DATABASE_NAME.replace(".db", "." + timeStr + ".txt"));
        return file.getAbsolutePath();
	}
	
    private static String createExternalDatabase(Context context) {
        File path = new File(Environment.getExternalStorageDirectory() +
        	"/ckanji/db/");
        File path2 = new File(Environment.getExternalStorageDirectory() +
            "/ckanji/fav_db/");
        File path3 = new File(Environment.getExternalStorageDirectory() +
            "/ckanji/fav_csv/");
        File file = new File(path, DATABASE_NAME);
        
        boolean mExternalStorageAvailable = false;
        boolean mExternalStorageWriteable = false;
        String state = Environment.getExternalStorageState();
        if (Environment.MEDIA_MOUNTED.equals(state)) {
            mExternalStorageAvailable = mExternalStorageWriteable = true;
        } else if (Environment.MEDIA_MOUNTED_READ_ONLY.equals(state)) {
            mExternalStorageAvailable = true;
            mExternalStorageWriteable = false;
        } else {
            mExternalStorageAvailable = mExternalStorageWriteable = false;
        }
        if (mExternalStorageAvailable && mExternalStorageWriteable) {
        	path.mkdirs();
        	path2.mkdirs();
        	path3.mkdirs();
        	return file.getAbsolutePath();
        } else {
        	//throw new IllegalArgumentException("无法创建目录");
        	return null;
        }
    }
}

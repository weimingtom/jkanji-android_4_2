package com.iteye.weimingtom.ckanji;

import org.json.JSONException;
import org.json.JSONObject;

import android.text.format.Time;
import android.util.Log;

public class CKanjiHistoryItem {
	private final static boolean D = false;
	private final static String TAG = "CKanjiHistoryItem";
	
	private long id = -1L;
	private String content;

	private String plainDesc;
	private Time plainTime;

	public long getId() {
		return id;
	}

	public void setId(long id) {
		this.id = id;
	}
	
	@Override
	public String toString() {
		return getContent();
	}
	
	public String getContent() {
		JSONObject jsonObject = new JSONObject();
		try {
			jsonObject.put("plainDesc", plainDesc);
			if (plainTime == null) {
				plainTime = new Time();
			}
			jsonObject.put("plainTime", plainTime.format2445());
		} catch (JSONException e) {
			e.printStackTrace();
		}
		content = jsonObject.toString();
		return content;
	}
	
	/**
	 * @see http://blog.csdn.net/jj120522/article/details/7710859
	 * @param content
	 */
	public void setContent(String content) {
		this.content = content;
		try {
			JSONObject jsonObject = new JSONObject(content);
			plainDesc = jsonObject.optString("plainDesc");
			String strPlainTime = jsonObject.optString("plainTime");
			plainTime = new Time();
			try {
				plainTime.parse(strPlainTime);
			} catch (Throwable e) {
				e.printStackTrace();
			}
		} catch (JSONException e) {
			e.printStackTrace();
		}
	}

	public String getPlainDesc() {
		return plainDesc;
	}

	public void setPlainDesc(String plainDesc) {
		this.plainDesc = plainDesc;
	}

	public Time getPlainTime() {
		return plainTime;
	}

	public void setPlainTime(Time plainTime) {
		this.plainTime = plainTime;
	}
}

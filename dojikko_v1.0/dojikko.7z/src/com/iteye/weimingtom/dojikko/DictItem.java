package com.iteye.weimingtom.dojikko;

import android.os.Parcel;
import android.os.Parcelable;

public class DictItem implements Parcelable {
	public String sound, name, mean;
	public int page;
	
	@Override
	public int describeContents() {
		return 0;
	}
	
	@Override
	public void writeToParcel(Parcel dest, int flags) {
		dest.writeString(sound);
		dest.writeString(name);
		dest.writeString(mean);
		dest.writeInt(page);
	}
	
	public static final Parcelable.Creator<DictItem> CREATOR = 
			new Parcelable.Creator<DictItem>() {         
				@Override
				public DictItem createFromParcel(Parcel in) {             
					return new DictItem(in);         
				}         
				
				@Override
				public DictItem[] newArray(int size) {             
					return new DictItem[size];         
				}     
			};
			
	private DictItem(Parcel in) {  
		sound = in.readString();
		name = in.readString();
		mean = in.readString();
		page = in.readInt();
	}
	
	public DictItem() {
		
	}
	
	public String getFullString() {
		String fullstr;
		if (name != null) {
			fullstr = name + "【" + sound + "】";
		} else {
			fullstr = sound;
		}
		fullstr += "\n\n" + mean;
		return fullstr;		
	}
	
	public String getSuggestion() {
		String suggest;
		if (name != null) {
			suggest = name + "【" + sound + "】";
		} else {
			suggest = sound;
		}
		return suggest;
	}
}

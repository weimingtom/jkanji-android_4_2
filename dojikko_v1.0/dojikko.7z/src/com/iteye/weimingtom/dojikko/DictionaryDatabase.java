package com.iteye.weimingtom.dojikko;

import android.app.SearchManager;
import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteQueryBuilder;
import android.provider.BaseColumns;
import android.util.Log;

import java.util.HashMap;

public class DictionaryDatabase {
	private final static boolean D = false;
	private final static String TAG = "DictionaryDatabase";
	
	private final static boolean ALWAYS_CLEAN_DATA = false;
	private final static String VERSION_STR = "v1.0";
	
    private DictionaryOpenHelper mDatabaseOpenHelper;
    
    private static final boolean USE_BUILDER = true;
    private static final HashMap<String, String> mColumnMap = buildColumnMap();
    
    private final static String VERSION_KEY = "version";
    
	public final static String[] QUERY_COLUMES = {
		DictionaryOpenHelper.KEY_WORD,
		DictionaryOpenHelper.KEY_READING,
		DictionaryOpenHelper.KEY_DEFINITION,
		DictionaryOpenHelper.KEY_WORD2,
	};
	public final static String QUERY_ORDER_BY = 
		DictionaryOpenHelper.KEY_READING + " ASC";
	
    public static String getVersion() {
    	if (ALWAYS_CLEAN_DATA) {
    		return VERSION_STR + " " + System.currentTimeMillis();
    	} else {
    		return VERSION_STR;
    	}
    }
    
    public DictionaryDatabase(Context context) {
        mDatabaseOpenHelper = new DictionaryOpenHelper(context);
    }
    
    public SQLiteDatabase mSQLiteDatabase;
    
    public void open() {
    	mSQLiteDatabase = mDatabaseOpenHelper.getWritableDatabase();	
    }
    
    public void close() {
    	if (mSQLiteDatabase != null) {
    		mSQLiteDatabase.close();
    		mSQLiteDatabase = null;
    	}
    	if (mDatabaseOpenHelper != null) {
    		mDatabaseOpenHelper.close();
    		mDatabaseOpenHelper = null;
    	}
    }

    private static HashMap<String,String> buildColumnMap() {
        HashMap<String,String> map = new HashMap<String,String>();
        map.put(DictionaryOpenHelper.KEY_WORD, DictionaryOpenHelper.KEY_WORD);
        map.put(DictionaryOpenHelper.KEY_DEFINITION, DictionaryOpenHelper.KEY_DEFINITION);
        map.put(DictionaryOpenHelper.KEY_READING, DictionaryOpenHelper.KEY_READING);
        map.put(DictionaryOpenHelper.KEY_TYPE, DictionaryOpenHelper.KEY_TYPE);
        map.put(BaseColumns._ID, "rowid AS " + BaseColumns._ID);
        map.put(SearchManager.SUGGEST_COLUMN_INTENT_DATA_ID, "rowid AS " + SearchManager.SUGGEST_COLUMN_INTENT_DATA_ID);
        map.put(SearchManager.SUGGEST_COLUMN_SHORTCUT_ID, "rowid AS " + SearchManager.SUGGEST_COLUMN_SHORTCUT_ID);
        map.put(DictionaryOpenHelper.KEY_WORD2, DictionaryOpenHelper.KEY_WORD2);
        return map;
    }

    public Cursor getWord(String rowId) {
        String selection = "rowid = ?";
        String[] selectionArgs = new String[] {rowId};
        return query(selection, selectionArgs);
    }

    public Cursor getWordMatches(String query, boolean isFulltext) {
        String selection = null;
        String[] selectionArgs = null;
        if (!DictionaryOpenHelper.USE_FULLTEXT) {
        	if (isFulltext) {
	        	selection = DictionaryOpenHelper.KEY_WORD + " LIKE ? " + " OR " + 
	                	DictionaryOpenHelper.KEY_READING + " LIKE ? " + " OR " +
	                	DictionaryOpenHelper.KEY_WORD2 + " LIKE ? " + " OR " +
	                	DictionaryOpenHelper.KEY_DEFINITION + " LIKE ? ";
	        	selectionArgs = new String[] {"%" + query + "%", "%" + query + "%", "%" + query + "%", "%" + query + "%"};        		
        	} else {
	        	selection = DictionaryOpenHelper.KEY_WORD + " LIKE ? " + " OR " + 
	                	DictionaryOpenHelper.KEY_READING + " LIKE ? " + " OR " +
	                	DictionaryOpenHelper.KEY_WORD2 + " LIKE ? ";
	        	selectionArgs = new String[] {query + "%", query + "%", query + "%"};
        	}
        } else {
        	if (isFulltext) {
	        	selection = DictionaryOpenHelper.FTS_VIRTUAL_TABLE + " MATCH ? " + " AND (" +
	        			DictionaryOpenHelper.KEY_WORD + " LIKE ? " + " OR " + 
	                	DictionaryOpenHelper.KEY_READING + " LIKE ? " + " OR " +
	                	DictionaryOpenHelper.KEY_WORD2 + " LIKE ? " + " OR " +
	                	DictionaryOpenHelper.KEY_DEFINITION + " LIKE ? )";	
	        	selectionArgs = new String[] {"\"" + tokenize(query) + "*\"",
	        			"%" + query + "%", "%" + query + "%", "%" + query + "%", "%" + query + "%"};        		
        	} else {
	        	selection = DictionaryOpenHelper.FTS_VIRTUAL_TABLE + " MATCH ? " + " AND (" +
	        			DictionaryOpenHelper.KEY_WORD + " LIKE ? " + " OR " + 
	                	DictionaryOpenHelper.KEY_READING + " LIKE ? " + " OR " +
	                	DictionaryOpenHelper.KEY_WORD2 + " LIKE ? )";	
	        	selectionArgs = new String[] {"\"" + tokenize(query) + "*\"",
	        			query + "%", query + "%", query + "%"};
        	}
        }
        return query(selection, selectionArgs);
    }

    private String getDictVersion() {
    	Cursor cursor = null;
        String word2 = null;
        try {
            String selection = DictionaryOpenHelper.KEY_TYPE + " = ?";
            String[] selectionArgs = new String[] {VERSION_KEY};
    		cursor = query(selection, selectionArgs);
    		if (D) {
        		Log.e(TAG, "query over");
        	}
        	while (cursor.moveToNext()) {
        		String word = cursor.getString(0);
	        	String reading = cursor.getString(1);
	        	String mean = cursor.getString(2);
	        	word2 = cursor.getString(3);
	        	if (D) {
	        		Log.e(TAG, "word2 == " + word2 + "," + word + "," + reading + "," + mean);
	        	}
	        }
        } catch (Throwable e) {
        	e.printStackTrace();
        } finally {
        	if (cursor != null) {
        		cursor.close();
        	}
        }
        return word2;
    }
    
    public boolean isNewVersion() {
    	String version = getDictVersion();
    	if (version != null && version.equals(getVersion())) {
    		if (D) {
        		Log.e(TAG, "new version == " + version);
        	}
    		return true;
    	} else {
    		if (D) {
        		Log.e(TAG, "old version == " + version);
        	}
    		return false;
    	}
    }
    
    public void addDictVersion() {
    	String version = getVersion();
    	this.addWord(VERSION_KEY, "", "", "", version);
    }
    
    private Cursor query(String selection, String[] selectionArgs) {
        if (mSQLiteDatabase == null) {
        	if (D) {
        		Log.e(TAG, "mSQLiteDatabase == null");
        	}
        	return null;
        }
        Cursor cursor = null;
        if (USE_BUILDER) {
	    	SQLiteQueryBuilder builder = new SQLiteQueryBuilder();
	        builder.setTables(DictionaryOpenHelper.FTS_VIRTUAL_TABLE);
	        builder.setProjectionMap(mColumnMap);
	        cursor = builder.query(mSQLiteDatabase,
	        	QUERY_COLUMES, selection, selectionArgs, 
	        	null, null, QUERY_ORDER_BY);
        } else {
        	cursor = mSQLiteDatabase.query(DictionaryOpenHelper.FTS_VIRTUAL_TABLE, 
        		QUERY_COLUMES, selection, selectionArgs, 
        		null, null, QUERY_ORDER_BY);
        }
        return cursor;
    }
    
    public long addWord(String type, String reading, String word, String definition, String word2) {
    	if (mSQLiteDatabase == null) {
        	return -1L;
        }
    	if (D) {
    		if (type != null && type.equals(VERSION_KEY)) {
    			Log.e(TAG, "addWord version " + type);
    		}
    	}
    	ContentValues values = new ContentValues();
        values.put(DictionaryOpenHelper.KEY_WORD, word);
        values.put(DictionaryOpenHelper.KEY_DEFINITION, definition);
        values.put(DictionaryOpenHelper.KEY_READING, reading);
        values.put(DictionaryOpenHelper.KEY_TYPE, type);
        values.put(DictionaryOpenHelper.KEY_WORD2, word2);
        if (DictionaryOpenHelper.USE_FULLTEXT) {
        	values.put(DictionaryOpenHelper.KEY_WORD_TOKEN, tokenize(word));
        	values.put(DictionaryOpenHelper.KEY_DEFINITION_TOKEN, tokenize(definition));
        	values.put(DictionaryOpenHelper.KEY_READING_TOKEN, tokenize(reading));
        }
        return mSQLiteDatabase.insert(DictionaryOpenHelper.FTS_VIRTUAL_TABLE, null, values);
    }
    
    private static String tokenize(String str) {  
    	if (str != null) {
	    	StringBuffer sb = new StringBuffer();
	        for (int i = 0; i < str.length(); i++) {  
	            char c = str.charAt(i);  
	            sb.append(c);  
	            if (c > 256 && i != str.length() - 1) {  
	                sb.append(' ');  
	            }
	        }
	        return sb.toString();
	    } else {
	    	return "";
	    }
    }
    
	public void deleteAllContent() {
		if (mSQLiteDatabase != null) {
			mSQLiteDatabase.delete(DictionaryOpenHelper.FTS_VIRTUAL_TABLE, 
					null, null);
			if (!DictionaryOpenHelper.USE_FULLTEXT) { 
				mSQLiteDatabase.execSQL(DictionaryOpenHelper.FTS_INDEX_DROP_WORD);
				mSQLiteDatabase.execSQL(DictionaryOpenHelper.FTS_INDEX_DROP_READING);
				mSQLiteDatabase.execSQL(DictionaryOpenHelper.FTS_INDEX_DROP_WORD2);
			}
		}
	}
	
	public void beginBatch() {
		if (mSQLiteDatabase != null) {
			mSQLiteDatabase.beginTransaction();
		}
	}
	
	public void endBatch() {
		if (mSQLiteDatabase != null) {
			mSQLiteDatabase.setTransactionSuccessful();
			mSQLiteDatabase.endTransaction();
		}
	}
	
    public void createIndex() {
    	if (mSQLiteDatabase != null) {
    		if (!DictionaryOpenHelper.USE_FULLTEXT) {
	    		mSQLiteDatabase.execSQL(DictionaryOpenHelper.FTS_INDEX_CREATE_WORD);
	    		mSQLiteDatabase.execSQL(DictionaryOpenHelper.FTS_INDEX_CREATE_READING);
	    		mSQLiteDatabase.execSQL(DictionaryOpenHelper.FTS_INDEX_CREATE_WORD2);
	    	}
    	}
    }
    
}

package com.iteye.weimingtom.dojikko;

import java.io.File;

import android.app.SearchManager;
import android.content.Context;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.os.Environment;
import android.util.Log;

public class DictionaryOpenHelper extends SQLiteOpenHelper {
	private final static boolean D = false;
	private final static String TAG = "DictionaryOpenHelper";
	
	public final static boolean USE_FULLTEXT = true;
	
    public static final String KEY_WORD = SearchManager.SUGGEST_COLUMN_TEXT_1;
    public static final String KEY_WORD_TOKEN = "word_token";
    public static final String KEY_READING = SearchManager.SUGGEST_COLUMN_TEXT_2;
    public static final String KEY_READING_TOKEN = "reading_token";
    public static final String KEY_DEFINITION = "definition";
    public static final String KEY_DEFINITION_TOKEN = "definition_token";
    public static final String KEY_TYPE = "type";
    public static final String FTS_VIRTUAL_TABLE = "FTSdictionary";
    public static final String KEY_WORD2 = "word2";
    
    private static final String DATABASE_NAME = "dict.db";
    private static final int DATABASE_VERSION = 2;
	
    private final Context mHelperContext;

    private static final String FTS_TABLE_CREATE =
            "CREATE TABLE " + FTS_VIRTUAL_TABLE +
            " (" +
            KEY_WORD + ", " +
            KEY_DEFINITION + ", " + 
            KEY_READING + ", " + 
            KEY_TYPE + ", " +
            KEY_WORD2 +
            ");";
    
    private static final String FTS_FULLTEXT_TABLE_CREATE =
            "CREATE VIRTUAL TABLE " + FTS_VIRTUAL_TABLE + " USING fts3 " +
            " (" +
            KEY_WORD + ", " +
            KEY_WORD_TOKEN + ", " +
            KEY_DEFINITION + ", " + 
            KEY_DEFINITION_TOKEN + ", " +
            KEY_READING + ", " + 
            KEY_READING_TOKEN + ", " +
            KEY_TYPE + ", " +
            KEY_WORD2 +
            ");";
    
    public static final String FTS_INDEX_CREATE_WORD =
            "CREATE INDEX IF NOT EXISTS wordidx ON " + FTS_VIRTUAL_TABLE +
            "(" +
            KEY_WORD +
            ");";

    public static final String FTS_INDEX_CREATE_READING =
            "CREATE INDEX IF NOT EXISTS readingidx ON " + FTS_VIRTUAL_TABLE +
            "(" +
            KEY_READING +
            ");";

    public static final String FTS_INDEX_CREATE_WORD2 =
            "CREATE INDEX IF NOT EXISTS word2idx ON " + FTS_VIRTUAL_TABLE +
            "(" +
            KEY_WORD2 +
            ");";
    
    public static final String FTS_INDEX_DROP_WORD =
            "DROP INDEX IF EXISTS " + FTS_VIRTUAL_TABLE + ".wordidx";

    public static final String FTS_INDEX_DROP_READING =
            "DROP INDEX IF EXISTS " + FTS_VIRTUAL_TABLE + ".readingidx";

    public static final String FTS_INDEX_DROP_WORD2 =
            "DROP INDEX IF EXISTS " + FTS_VIRTUAL_TABLE + ".word2idx";
    
    public DictionaryOpenHelper(Context context) {
        super(context, /*DATABASE_NAME*/createExternalDatabase(context), null, DATABASE_VERSION);
        mHelperContext = context;
    }

    @Override
    public void onCreate(SQLiteDatabase db) {
        if (!USE_FULLTEXT) {
        	db.execSQL(FTS_TABLE_CREATE);
        } else {
        	db.execSQL(FTS_FULLTEXT_TABLE_CREATE);
        }
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        if (D) {
        	Log.w(TAG, "Upgrading database from version " + oldVersion + " to "
                + newVersion + ", which will destroy all old data");
        }
        db.execSQL("DROP TABLE IF EXISTS " + FTS_VIRTUAL_TABLE);
        onCreate(db);
    }
/*
    private void loadWords() throws IOException {
    	if (D) {
    		Log.d(TAG, "Loading words...");
    	}
    	final AssetManager am = mHelperContext.getAssets();
        InputStream inputStream = am.open("jpwords_3_4.csv");
        BufferedReader reader = new BufferedReader(new InputStreamReader(inputStream, "utf8"));
        InputStream inputStream2 = am.open("sj2gb_3_4.txt");
        BufferedReader reader2 = new BufferedReader(new InputStreamReader(inputStream2, "utf8"));
        try {
            String line;
            HashMap<Character, Character> map = new HashMap<Character, Character>();
            while ((line = reader2.readLine()) != null) {
                String[] strings = TextUtils.split(line, ",");
                if (strings.length < 2) {
                	continue;
                }
                if (strings[0] != null && strings[0].length() > 0 &&
                	strings[1] != null && strings[1].length() > 0) {
                	map.put(strings[0].charAt(0), strings[1].charAt(0));
                }
            }
            while ((line = reader.readLine()) != null) {
                String[] strings = TextUtils.split(line, ",");
                if (strings.length < 4) {
                	continue;
                }
                
                StringBuffer word2 = new StringBuffer();
                for (int i = 0; i < strings[2].length(); i++) {
                	char cho = strings[2].charAt(i);
                	Character ch = map.get(cho);
                	if (ch != null) {
                		word2.append(ch);
                	} else {
                		word2.append(cho);
                	}
                }
                long id = addWord(strings[0], strings[1], strings[2], strings[3], word2.toString());
                if (D && id < 0) {
                    Log.e(TAG, "unable to add word: " + strings[1]);
                }
            }
        } finally {
        	if (reader2 != null) {
        		reader2.close();
        	}
        	if (reader != null) {
        		reader.close();
        	}
        }
        if (D) {
        	Log.d(TAG, "DONE loading words.");
        }
        mDatabase.execSQL(FTS_INDEX_CREATE);
        mDatabase.execSQL(FTS_INDEX_CREATE_2);
    }
*/
    
    public static String createExternalDatabase(Context context) {
        File path = new File(Environment.getExternalStorageDirectory() +
        	"/Android/data/" + context.getPackageName());
        File file = new File(path, DATABASE_NAME);
        
        boolean mExternalStorageAvailable = false;
        boolean mExternalStorageWriteable = false;
        String state = Environment.getExternalStorageState();
        if (Environment.MEDIA_MOUNTED.equals(state)) {
            mExternalStorageAvailable = mExternalStorageWriteable = true;
        } else if (Environment.MEDIA_MOUNTED_READ_ONLY.equals(state)) {
            mExternalStorageAvailable = true;
            mExternalStorageWriteable = false;
        } else {
            mExternalStorageAvailable = mExternalStorageWriteable = false;
        }
        if (mExternalStorageAvailable && mExternalStorageWriteable) {
        	path.mkdirs();
        	return file.getAbsolutePath();
        } else {
        	throw new IllegalArgumentException("无法创建目录");
        	//return null;
        }
    }
}

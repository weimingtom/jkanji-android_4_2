package com.iteye.weimingtom.dojikko;

import java.lang.ref.WeakReference;

import android.app.Activity;
import android.app.AlertDialog;
import android.app.Dialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.net.Uri;
import android.text.Spannable;
import android.text.SpannableString;
import android.text.TextUtils;
import android.text.method.LinkMovementMethod;
import android.text.method.MovementMethod;
import android.text.style.ClickableSpan;
import android.view.View;
import android.widget.TextView;

public class LinkMenuSpan extends ClickableSpan {
	public interface OnLinkMenuClickListener {
		void onExpand();
	}
	
	public static final int DIALOG_HELP_ID = 1001;
	
	private final static String DELIMITER = " | ";
	public final static String MENU_EXIT = "Back";
	public final static String MENU_HOMEPAGE = "Webpage";
	public final static String MENU_HELP = "Help";
	public final static String MENU_EXPAND = "Expand";
	private final static String[] LINK_MENUS = {
		MENU_EXIT,
		MENU_HELP,
		MENU_EXPAND,
		//MENU_HOMEPAGE,
	};
	
    private WeakReference<Activity> act;
    private String selectStr;
    OnLinkMenuClickListener mOnLinkMenuClickListener; 

    public LinkMenuSpan(Activity activity, String selectStr, 
    	OnLinkMenuClickListener	onLinkMenuClickListener) {
        this.act = new WeakReference<Activity>(activity);
        this.selectStr = selectStr;
        this.mOnLinkMenuClickListener = onLinkMenuClickListener;
    }

    @Override
    public void onClick(View widget) {
    	if (MENU_EXIT.equals(selectStr)) {
    		act.get().finish();
    	} else if (MENU_HOMEPAGE.equals(selectStr)) {
    		try {
	        	act.get().startActivity(new Intent(Intent.ACTION_VIEW,
	                Uri.parse(act.get().getText(R.string.homepage)
	                	.toString())));
    		} catch (Throwable e) {
    			e.printStackTrace();
    		}
    	} else if (MENU_HELP.equals(selectStr)) {
    		act.get().showDialog(DIALOG_HELP_ID);       		
    	} else if (MENU_EXPAND.equals(selectStr)) {
    		if (mOnLinkMenuClickListener != null) {
    			mOnLinkMenuClickListener.onExpand();
    		}
    	}
    }
    
    public static void addClickableMenu(Activity activity, TextView mLink, OnLinkMenuClickListener onLinkMenuClickListener) {
        String text = TextUtils.join(DELIMITER, LINK_MENUS);
        SpannableString str = new SpannableString(text);
        for (String item : LINK_MENUS) {
        	if (onLinkMenuClickListener == null && 
        		MENU_EXPAND.equals(item)) {
        		continue;
        	}
            int idx = text.indexOf(item);
            if (idx != -1) {
                int end = idx + 1;
                if (end > str.length() - 1) {
                    end = str.length();
                }
                str.setSpan(new LinkMenuSpan(activity, item, onLinkMenuClickListener), idx, idx + item.length(),
                        Spannable.SPAN_EXCLUSIVE_INCLUSIVE);
            }
        }
        mLink.setText(str);
        if (true) {
        	mLink.setLinkTextColor(0xff3c6db0);
        } else {
        	mLink.setLinkTextColor(activity.getResources().getColorStateList(R.color.link_colors));
        }
        MovementMethod m = mLink.getMovementMethod();
        if ((m == null) || !(m instanceof LinkMovementMethod)) {
            if (mLink.getLinksClickable()) {
            	mLink.setMovementMethod(LinkMovementMethod.getInstance());
            }
        }
    }
    
    public static Dialog onCreateDialog(final Activity act, int id) {
 	    Dialog dialog = null;
 	    switch(id) {
 	    case LinkMenuSpan.DIALOG_HELP_ID:
     		return new AlertDialog.Builder(act)
     			.setTitle(R.string.help_title)
     			.setIcon(R.drawable.ic_launcher)
     			.setMessage(R.string.help_content)
     			.setPositiveButton(R.string.ok, new DialogInterface.OnClickListener() {
     				public void onClick(DialogInterface dialog, int id) {
     					
     				}
     			})
     			.setNegativeButton(R.string.gohome, new DialogInterface.OnClickListener() {
     				public void onClick(DialogInterface dialog, int id) {
     		    		try {
     			        	act.startActivity(new Intent(Intent.ACTION_VIEW,
     			                Uri.parse(act.getText(R.string.homepage)
     			                	.toString())));
     		    		} catch (Throwable e) {
     		    			e.printStackTrace();
     		    		}
     				}
     			})
     	       .create();
 	    }
 	    return dialog;
    }
}

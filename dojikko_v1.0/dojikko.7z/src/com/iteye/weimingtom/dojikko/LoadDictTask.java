package com.iteye.weimingtom.dojikko;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.lang.ref.WeakReference;
import java.util.ArrayList;

import ru.j2ee.moskvin.SearchDemo;
import android.content.res.AssetManager;
import android.os.AsyncTask;
import android.view.View;
import android.widget.Toast;

/**
 * FIXME: MAY BE in-memory database
 * @author Administrator
 *
 */
public class LoadDictTask extends AsyncTask<Void, DictItem, Void> {
	private final static int PAGE_MAX = 69; 
	
	private WeakReference<SearchDemo> act;
	private boolean isStop = false;
	private ArrayList<DictItem> mDictItems = new ArrayList<DictItem>();
	private DictionaryDatabase db;
	private boolean isCreateError = false;

	public LoadDictTask(SearchDemo activity) {
		super();
		this.act = new WeakReference<SearchDemo>(activity);
	}

	@Override
	protected void onPreExecute() {
		super.onPreExecute();
		this.act.get().loadingPanel.setVisibility(View.VISIBLE);
	}

	@Override
	protected Void doInBackground(Void... params) {
		if (SearchDemo.USE_DATABASE) {
			try {
				this.db = new DictionaryDatabase(this.act.get());
			} catch (Throwable e) {
				e.printStackTrace();
				isCreateError = true;
				return null;
			}
			if (this.db == null) {
				return null;
			}
			this.db.open();
			if (this.db.isNewVersion()) {
				//this.db.deleteAllContent();
				return null;
			} else {
				this.db.deleteAllContent();
				//return null;
			}
		}
		AssetManager am = this.act.get().getAssets();
		int i = 1;
		for (; i <= PAGE_MAX && !isStop; i++) {
			InputStream istr = null;
			InputStreamReader reader = null;
			BufferedReader buf = null;
			if (this.db != null) {
				this.db.beginBatch();
			}
			try {
				istr = am.open("dict/" + int2str(i) + ".txt", 
					AssetManager.ACCESS_STREAMING);
				reader = new InputStreamReader(istr, "UTF-8");
				buf = new BufferedReader(reader);
				String line;
				DictItem item = new DictItem();
				int itempos = 0;
				while((line = buf.readLine()) != null) {
					if (line == null || line.length() == 0) {
						itempos = 0;
						if (item != null) {
							item.page = i;
							beginProgressUpdate(item);
							item = new DictItem();
						}
					} else {
						switch (itempos) {
						case 0:
							item.sound = line;
							itempos = 1;
							break;
							
						case 1:
							if (line.startsWith("[")) {
								item.name = null;
								item.mean = line + "\n";
								itempos = 3;
							} else {
								item.name = line;
								itempos = 2;						
							}
							break;
							
						default:
							if (item.mean == null) {
								item.mean = "";
							}
							item.mean += line + "\n";
							itempos++;
							break;
						}
					}
				}
				itempos = 0;
				if (item != null) {
					item.page = i;
					beginProgressUpdate(item);
				}
				this.publishProgress(item);
			} catch (IOException e) {
				e.printStackTrace();
				isCreateError = true;
			} catch (Throwable ex) {
				ex.printStackTrace();
				isCreateError = true;
			} finally {
				if (buf != null) {
					try {
						buf.close();
					} catch (IOException e) {
						e.printStackTrace();
					}
				}
				if (reader != null) {
					try {
						reader.close();
					} catch (IOException e) {
						e.printStackTrace();
					}
				}
				if (istr != null) {
					try {
						istr.close();
					} catch (IOException e) {
						e.printStackTrace();
					}
				}
				if (this.db != null) {
					this.db.endBatch();
				}
			}
		}
		if (i <= PAGE_MAX) {
			isCreateError = true;
		}
		if (SearchDemo.USE_DATABASE) {
			if (this.db != null) {
				if (!isCreateError) {
					this.db.createIndex();
					this.db.addDictVersion();
				}
				this.db.close();
				this.db = null;
			}
		}
		return null;
	}
	
	@Override
	protected void onPostExecute(Void result) {
		super.onPostExecute(result);
		this.act.get().loadingPanel.setVisibility(View.INVISIBLE);
		this.act.get().dictItems = mDictItems;
		this.act.get().loadDictTask = null;
		if (SearchDemo.USE_DATABASE) {
			if (isCreateError) {
				Toast.makeText(this.act.get(), 
					this.act.get().getText(R.string.create_db_error), 
					Toast.LENGTH_SHORT).show();
			}
		}
	}
	
	private void beginProgressUpdate(DictItem item) {
		if (SearchDemo.USE_DATABASE) {
			if (this.db != null) {
				this.db.addWord(
					"", 
					item.sound, 
					item.name, 
					item.mean, 
					"");
			}
		} else {
			mDictItems.add(item);
		}
		if (isStop) {
			isCreateError = true;
			throw new RuntimeException("stop task!");
		}
	}
	
	@Override
	protected void onProgressUpdate(DictItem... values) {
		super.onProgressUpdate(values);
		this.act.get().loadingInfo.setText(
			this.act.get().getText(R.string.creating_str) + 
			" (" + values[0].page + " / " + PAGE_MAX + ")");
		if (isStop) {
			isCreateError = true;
			throw new RuntimeException("stop task!");
		}
	}

	public void stop() {
		isStop = true;
		isCreateError = true;
	}
	
	private String int2str(int i) {
		if (i < 10) {
			return "00" + Integer.toString(i);
		} else if (i < 100) {
			return "0" + Integer.toString(i);
		} else {
			return Integer.toString(i);
		}
	}
}

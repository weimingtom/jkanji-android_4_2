package com.iteye.weimingtom.dojikko;

import java.util.ArrayList;

import ru.j2ee.moskvin.SuggestionArrayAdapter;

import android.app.Activity;
import android.app.Dialog;
import android.content.Intent;
import android.os.Bundle;
import android.widget.ListView;
import android.widget.TextView;

public class ResultsActivity extends Activity {
	public final static String EXTRA_KEYWORD_KEY = "ResultsActivity.keyword";
	public final static String EXTRA_RESULTS_KEY = "ResultsActivity.results";
	
	private ListView resultView;
	private ArrayList<DictItem> resultsArray;
	private SuggestionArrayAdapter searchAdapter;
	private TextView mLink;
	private String keyword;
	
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		this.setContentView(R.layout.results);
		
		mLink = (TextView) findViewById(R.id.link);
		resultView = (ListView) findViewById(R.id.search_list);
		Intent intent = this.getIntent();
		
		LinkMenuSpan.addClickableMenu(this, mLink, null);
		if (intent != null) {
			resultsArray = intent.getParcelableArrayListExtra(EXTRA_RESULTS_KEY);
			keyword = intent.getStringExtra(EXTRA_KEYWORD_KEY);
		} else {
			resultsArray = new ArrayList<DictItem>();
		}
		searchAdapter = new SuggestionArrayAdapter(this, R.layout.search_list_item, resultsArray, 
				SuggestionArrayAdapter.FULL_TYPE);
		searchAdapter.setKeyword(keyword);
		searchAdapter.notifyDataSetChanged();
		resultView.setAdapter(searchAdapter);
	}
	
	@Override
	protected Dialog onCreateDialog(int id) {
		return LinkMenuSpan.onCreateDialog(this, id);
	}
}

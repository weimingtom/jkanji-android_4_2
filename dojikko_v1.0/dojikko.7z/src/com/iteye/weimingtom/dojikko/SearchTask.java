package com.iteye.weimingtom.dojikko;

import java.lang.ref.WeakReference;
import java.util.ArrayList;

import ru.j2ee.moskvin.SearchDemo;
import android.content.Intent;
import android.database.Cursor;
import android.os.AsyncTask;
import android.util.Log;
import android.widget.Toast;

public class SearchTask extends AsyncTask<Void, Void, Void> {
	private final static boolean D = false;
	private static final String TAG = "SearchTask";
	
	private WeakReference<SearchDemo> act;
	private final String query;
	private boolean isStop = false;
	private ArrayList<DictItem> results = new ArrayList<DictItem>();
	private boolean isStartAct = false;
	private boolean isCreateError = false;

	/**
	 * Default constructor
	 */
	public SearchTask(SearchDemo activity, String query, boolean isStartAct) {
		super();
		this.act = new WeakReference<SearchDemo>(activity);
		this.query = query;
		this.isStartAct = isStartAct;
	}
	
	@Override
	protected void onPreExecute() {
		this.act.get().searchAdapter.clear();
		this.act.get().searchAdapter.setKeyword(null);
		this.act.get().searchAdapter.notifyDataSetChanged();
		super.onPreExecute();
	}

	@Override
	protected Void doInBackground(Void... params) {
		if (SearchDemo.USE_DATABASE) {
			DictionaryDatabase db = null;
			try {
				 db = new DictionaryDatabase(this.act.get());
			} catch (Throwable e) {
				e.printStackTrace();
				isCreateError = true;
				return null;
			}
			if (db == null) {
				return null;
			}
			db.open();
			Cursor cursor = null;
			try {
				cursor = db.getWordMatches(query, isStartAct);
				while (cursor.moveToNext()) {
	        		DictItem item = new DictItem();
		        	item.name = cursor.getString(0);
	        		item.sound = cursor.getString(1);
		        	item.mean = cursor.getString(2);
		        	results.add(item);
		        }
			} catch (Throwable e) {
				e.printStackTrace();
			} finally {
				if (cursor != null) {
					cursor.close();
				}
			}
			db.close();
		} else {
			ArrayList<DictItem> dictItems = this.act.get().dictItems;
			if (dictItems != null) {
				if (D) {
					Log.e(TAG, "doInBackground " + dictItems.size());
				}
				if (this.query != null && this.query.length() > 0) {
					for (int i = 0; !isStop && i < dictItems.size(); i++) {
						DictItem item = dictItems.get(i);
						if (item != null) {
							if ((item.name != null && item.name.startsWith(this.query)) ||
								(item.sound != null && item.sound.startsWith(this.query))) {
								results.add(item);
							}
						}
					}
				}
			} else {
				if (D) {
					Log.e(TAG, "dictItems == null");
				}
			}
		}
		return null;
	}
	
	@Override
	protected void onPostExecute(Void result) {
		super.onPostExecute(result);
		for (int i = 0; i < results.size(); i++) {
			this.act.get().searchAdapter.add(results.get(i));
		}
		this.act.get().searchAdapter.setKeyword(query);
		this.act.get().searchAdapter.notifyDataSetChanged();
		this.act.get().searchTask = null;
		if (isStartAct) {
			this.act.get().startActivity(new Intent(this.act.get(), ResultsActivity.class)
				.putParcelableArrayListExtra(ResultsActivity.EXTRA_RESULTS_KEY, results)
				.putExtra(ResultsActivity.EXTRA_KEYWORD_KEY, query)
			);
		}
		if (isCreateError) {
			Toast.makeText(this.act.get(), 
				this.act.get().getText(R.string.create_db_error), 
				Toast.LENGTH_SHORT).show();
		}
	}
	
	public void stop() {
		isStop = true;
	}
}

package ru.j2ee.moskvin;

import java.util.ArrayList;

import com.iteye.weimingtom.dojikko.DictItem;
import com.iteye.weimingtom.dojikko.LinkMenuSpan;
import com.iteye.weimingtom.dojikko.LoadDictTask;
import com.iteye.weimingtom.dojikko.R;
import com.iteye.weimingtom.dojikko.ResultsActivity;
import com.iteye.weimingtom.dojikko.SearchTask;

import ru.j2ee.moskvin.widget.SearchPanel;
import ru.j2ee.moskvin.widget.SearchPanel.SearchListener;
import android.app.Activity;
import android.app.AlertDialog;
import android.app.Dialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.graphics.drawable.AnimationDrawable;
import android.os.Bundle;
import android.widget.ImageView;
import android.widget.ListView;
import android.widget.RelativeLayout;
import android.widget.TextView;

public class SearchDemo extends Activity implements SearchListener {
	private final static boolean D = false;
	private static final String TAG = "SearchDemo";
	
	public final static boolean USE_DATABASE = true;
	
	private TextView mLink;
	private SearchPanel searchPanel;
	private ListView searchList;
	private ArrayList<DictItem> suggestions;
	public SuggestionArrayAdapter searchAdapter;
	public SearchTask searchTask;
	private ImageView loadingImage;
	private AnimationDrawable loadingAnimation;
	public RelativeLayout loadingPanel;
	public LoadDictTask loadDictTask;
	public TextView loadingInfo;
	public ArrayList<DictItem> dictItems;
	private LinkMenuSpan span;
	
	/** Called when the activity is first created. */
	@Override
	public void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.main);
		
		mLink = (TextView) findViewById(R.id.link);
		searchPanel = (SearchPanel) findViewById(R.id.search_panel);
		searchList = (ListView) findViewById(R.id.search_list);
		loadingPanel = (RelativeLayout) findViewById(R.id.loading_panel);
		
		LinkMenuSpan.addClickableMenu(this, mLink, new LinkMenuSpan.OnLinkMenuClickListener() {
			@Override
			public void onExpand() {
				searchAdapter.switchExpand();
			}
		});
		searchPanel.setSearchListView(searchList);
		searchPanel.setSearchListener(this);
		suggestions = new ArrayList<DictItem>();
		searchAdapter = new SuggestionArrayAdapter(this, R.layout.search_list_item, suggestions,
				SuggestionArrayAdapter.SUGGEST_TYPE);
		searchPanel.setSearchAdapter(searchAdapter);
	
		loadingImage = (ImageView) findViewById(R.id.loading_image);
		loadingImage.setBackgroundResource(R.drawable.loading_ani);
		loadingAnimation = (AnimationDrawable) loadingImage.getBackground();
	
		loadingInfo = (TextView) findViewById(R.id.loading_info); 
		
		if (loadDictTask != null) {
			loadDictTask.stop();
		}
		loadDictTask = new LoadDictTask(this);
		loadDictTask.execute();
	}

	/**
	 * @see ru.j2ee.moskvin.widget.SearchPanel.SearchListener#onAutoSuggestion(java.lang.String)
	 */
	@Override
	public void onAutoSuggestion(String query) {
		if (searchTask != null) {
			searchTask.stop();
		}
		searchTask = new SearchTask(this, query, false);
		searchTask.execute();
	}

	@Override
	public void onClear() {
		if (searchTask != null) {
			searchTask.stop();
			searchTask = null;
		}
	}

	@Override
	public void onClickSearchResult(String query) {
		if (searchTask != null) {
			searchTask.stop();
		}
		searchTask = new SearchTask(this, query, true);
		searchTask.execute();
	}

	@Override
	public void onClickSearchSuggestion(int position) {
		if (position >= 0 && position < searchAdapter.getCount()) {
			ArrayList<DictItem> data = new ArrayList<DictItem>();
			data.add(searchAdapter.getItem(position));
			this.startActivity(new Intent(this, ResultsActivity.class)
				.putParcelableArrayListExtra(ResultsActivity.EXTRA_RESULTS_KEY, data)
				.putExtra(ResultsActivity.EXTRA_KEYWORD_KEY, searchAdapter.getKeyword())
			);
		}
	}
	
	@Override
	protected void onPause() {
		super.onPause();
		if (loadDictTask != null) {
			loadDictTask.stop();
		}
	}

	@Override
	protected void onDestroy() {
		// TODO Auto-generated method stub
		super.onDestroy();
		if (loadDictTask != null) {
			loadDictTask.stop();
		}
	}

	@Override
	protected Dialog onCreateDialog(int id) {
		return LinkMenuSpan.onCreateDialog(this, id);
	}

	@Override
	public void onWindowFocusChanged(boolean hasFocus) {
		super.onWindowFocusChanged(hasFocus);
		loadingAnimation.start();
	}
}
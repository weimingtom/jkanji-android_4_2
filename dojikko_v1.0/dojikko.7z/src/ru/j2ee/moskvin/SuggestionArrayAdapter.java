/**
 * 
 */
package ru.j2ee.moskvin;

import java.util.List;

import com.iteye.weimingtom.dojikko.DictItem;
import com.iteye.weimingtom.dojikko.R;

import android.content.Context;
import android.graphics.Color;
import android.text.Spannable;
import android.text.SpannableString;
import android.text.style.ForegroundColorSpan;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.TextView;


/**
 * @author Nikolay Moskvin <moskvin@j2ee.ru>
 * @date 01.11.2010
 *
 */
public class SuggestionArrayAdapter extends ArrayAdapter<DictItem> {
	public final static int SUGGEST_TYPE = 0;
	public final static int FULL_TYPE = 1;
	
	private Context context;
	private List<DictItem> items;
	private int type = SUGGEST_TYPE;
	private String keyword;
	
	/**
	 * @param context
	 * @param textViewResourceId
	 * @param objects
	 */
	public SuggestionArrayAdapter(Context context, 
		int textViewResourceId, 
		List<DictItem> items, int type) {
		super(context, textViewResourceId, items);
		this.context = context;
		this.items = items;
		this.type = type;
	}

	@Override
	public View getView(int position, View convertView, ViewGroup parent) {
		View view = convertView;
		if (view == null) {
			view = View.inflate(context, R.layout.search_list_item, null);
		}
		TextView textView = (TextView) view.findViewById(R.id.search_list_item_text);
		if (type == FULL_TYPE) {
			textView.setText(getColorString(items.get(position).getFullString(), keyword));
		} else {
			textView.setText(getColorString(items.get(position).getSuggestion(), keyword));
		}
		return view;
	}
	
	public void switchExpand() {
		if (type == FULL_TYPE) {
			type = SUGGEST_TYPE;
		} else {
			type = FULL_TYPE;
		}
		this.notifyDataSetChanged();
	}
	
    public void setKeyword(String str) {
    	keyword = str;
    }
    
    public String getKeyword() {
    	return keyword;
    }
    
    private CharSequence getColorString(String str, String keyword) {
    	if (str != null) {
    		SpannableString spannable = new SpannableString(str);
    		if (keyword != null && keyword.length() > 0) {
    			int start = 0;
    			while (start < str.length()) {
    				int index = str.indexOf(keyword, start);
    				if (index == -1) {
    					break;
    				} else {
    					ForegroundColorSpan span = new ForegroundColorSpan(Color.RED);
    					spannable.setSpan(span, index, index + keyword.length(), Spannable.SPAN_EXCLUSIVE_EXCLUSIVE);
    					start = index + keyword.length();
    				}
    			}
    		}
    		return spannable;
    	} else {
    		return null;
    	}
    }
}

/**
 * 
 */
package ru.j2ee.moskvin.widget;

import com.iteye.weimingtom.dojikko.DictItem;
import com.iteye.weimingtom.dojikko.R;

import android.content.Context;
import android.text.Editable;
import android.text.TextWatcher;
import android.util.AttributeSet;
import android.util.Log;
import android.view.KeyEvent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.inputmethod.EditorInfo;
import android.view.inputmethod.InputMethodManager;
import android.widget.AbsListView;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.ListView;
import android.widget.RelativeLayout;
import android.widget.TextView;
import android.widget.EditText;
import android.widget.AbsListView.OnScrollListener;
import android.widget.AdapterView.OnItemClickListener;

/**
 * Initialize search panels and fields
 * For normal work you must have $(tag)_page1 and $(tag)_page2 group view,
 * where 
 * For example:
 * <pre>
 * {@code
 * <!-- Page 2 -->
 * <ScrollView
 *		android:tag="@string/tag_page1"
 *		android:layout_width="fill_parent"
 *		android:layout_height="fill_parent"/>
 * <!-- Page 2 -->
 * <com.freshdirect.android.widget.SearchListView
 *		android:tag="@string/tag_page2"
 *		android:layout_width="fill_parent"
 *		android:layout_height="fill_parent"/>
 * }
 * </pre>
 * 
 * @author Nikolay Moskvin <moskvin@j2ee.ru>
 * @date 23.10.2010
 * */
public class SearchPanel extends RelativeLayout implements 
			TextWatcher,
			EditText.OnEditorActionListener, OnScrollListener {
	
	private final static boolean D = false;
	private final static String TAG = "SearchPanel";
	
	private Context context;
	
	private EditText searchEditText;
	private Button buttonCancel;
	private ListView searchList;
	
	private SearchListener searchListener;
	private boolean applicationSetText = false;

	public interface SearchListener {
		void onAutoSuggestion(String query);
		void onClickSearchResult(String query);
		void onClickSearchSuggestion(int position);
		void onClear();
	}

	/**
	 * Constructor with style
	 * @param context is current context of activity
	 * @param attrs is set of attributes
	 * @param defStyle is concrete style
	 */
	public SearchPanel(Context context, AttributeSet attrs, int defStyle) {
		super(context, attrs, defStyle);
		init(context);
	}

	/**
	 * Constructor with attributes
	 * @param context is current context of activity
	 * @param attrs is set of attributes
	 */
	public SearchPanel(Context context, AttributeSet attrs) {
		super(context, attrs);
		init(context);
	}

	/**
	 * Simple constructor
	 * @param context is current context of activity
	 */
	public SearchPanel(Context context) {
		super(context);
		init(context);
	}

	/**
	 * Inflate search_panel.xml and 
	 * configuration all view
	 * @param context is current context of activity 
	 */
	private void init(Context context) {
		this.context = context;
		LayoutInflater inflater = (LayoutInflater) context.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
		inflater.inflate(R.layout.search_panel, this, true);

		buttonCancel = (Button) findViewById(R.id.search_button_cancel);
		buttonCancel.setOnClickListener(new OnClickListener() {
			public void onClick(View v) {
				searchEditText.getText().clear();
				showKeyboard();
				if (searchListener != null) {
					searchListener.onClear();
				}
			}
		});

		searchEditText = (EditText) findViewById(R.id.search_edit_text);
		searchEditText.addTextChangedListener(this);
		searchEditText.setOnEditorActionListener(this);
	}

	@Override
	public void beforeTextChanged(CharSequence s, int start, int count, int after) {
		
	}

	@Override
	public void onTextChanged(CharSequence s, int start, int before, int count) {
		
	}
	
	@Override
	public void afterTextChanged(Editable s) {
		if (!applicationSetText) {
			String query = s.toString();
			if (searchListener != null) {
				searchListener.onAutoSuggestion(query);
			}
		} else {
			applicationSetText = false;
		}
	}

	@Override
	public boolean onEditorAction(TextView v, int actionId, KeyEvent event) {
		if (D) {
			if (actionId == EditorInfo.IME_ACTION_UNSPECIFIED) {
				Log.e(TAG, "onEditorAction IME_ACTION_UNSPECIFIED");
			} else if (actionId == EditorInfo.IME_ACTION_SEARCH) {
				Log.e(TAG, "onEditorAction IME_ACTION_SEARCH");
			} else {
				Log.e(TAG, "onEditorAction");
			}
		}
		if (actionId == EditorInfo.IME_ACTION_SEARCH || 
			actionId == EditorInfo.IME_ACTION_UNSPECIFIED) {
			String query = v.getText().toString();
			if (searchListener != null) {
				searchListener.onClickSearchResult(query);
			}
			return true;
		}
		return false;
	}

	public void setSearchListView(ListView listView) {
		searchList = listView;
		searchList.setOnScrollListener(this);
		searchList.setOnItemClickListener(new OnItemClickListener() { 
			@Override
			public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
				if (searchListener != null) {
					searchListener.onClickSearchSuggestion(position);
				}
			}
		});
	}
	
	public void setSearchListener(SearchListener searchListener) {
		this.searchListener = searchListener;
	}

	public void setSearchAdapter(ArrayAdapter<DictItem> searchAdapter) {
		searchList.setAdapter(searchAdapter);
	}

	public void hideKeyboard() {
		InputMethodManager imm = (InputMethodManager)
			context.getSystemService(Context.INPUT_METHOD_SERVICE);
		if (searchEditText != null) {
			imm.hideSoftInputFromWindow(searchEditText.getWindowToken(), 0);
		}
	}
	
	public void showKeyboard() {
		InputMethodManager imm = (InputMethodManager)context.getSystemService(Context.INPUT_METHOD_SERVICE);
		if (searchEditText != null) {
			imm.showSoftInput(searchEditText, 0);
		}
	}

	@Override
	public void onScroll(AbsListView view, int firstVisibleItem,
			int visibleItemCount, int totalItemCount) {
	}

	@Override
	public void onScrollStateChanged(AbsListView view, int scrollState) {
		hideKeyboard();
	}
}
